# 📋 PANDUAN SETUP GOOGLE SHEETS
## Dashboard Pemantauan Anggaran BLU – RSUP Fatmawati

---

## ✅ TAHAP 1 SELESAI: File Aplikasi
Berikut file yang telah dibuat:
- `index.html` – Struktur halaman dashboard
- `style.css`  – Tampilan & layout
- `app.js`     – Logic, koneksi Sheets, grafik, export

---

## 🔗 TAHAP 2: Setup Google Sheets

### Langkah 1 – Buka Google Sheets Anda
URL: https://docs.google.com/spreadsheets/d/1NJk35mHBdus15lzhnsCzL3EZ5UfOQnnaKqhvOpwwkxo

### Langkah 2 – Buat Tab/Sheet dengan nama persis:
```
KPI           → Data KPI utama
Trend         → Data trend bulanan
Komposisi     → Komposisi belanja operasional
UnitKerja     → Realisasi per unit kerja
ArusKas       → Arus kas (bisa gabung di KPI)
Rincian       → Rincian realisasi anggaran
Peringatan    → Peringatan & catatan
```

### Langkah 3 – Struktur Kolom Per Sheet

#### Sheet: KPI (1 baris data)
| pendapatan | pendapatan_target | belanja_op | belanja_op_pagu | belanja_modal | belanja_modal_pagu | total_belanja | total_belanja_pagu | surplus | surplus_proj | saldo_kas | saldo_hari | kas_awal | kas_masuk | kas_keluar |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2450 | 2750 | 1980 | 2200 | 250 | 400 | 2230 | 2600 | 220 | 280 | 870 | 76 | 650 | 2650 | 2430 |

#### Sheet: Trend (per baris = per bulan)
| bulan | pendapatan | belanja_op | total_belanja |
|---|---|---|---|
| Jan | 450 | 320 | 380 |
| Feb | 900 | 680 | 800 |
| ... | ... | ... | ... |

#### Sheet: Komposisi
| jenis | nilai | pct |
|---|---|---|
| Belanja Pegawai | 880 | 44.4 |
| Belanja Barang  | 520 | 26.3 |

#### Sheet: UnitKerja
| nama | pagu | realisasi | pct |
|---|---|---|---|
| 1. Instalasi Gawat Darurat | 250 | 230 | 92.00 |

#### Sheet: Rincian
| jenis | pagu | realisasi | pct | is_cat | is_sub |
|---|---|---|---|---|---|
| A. PENDAPATAN | 2750 | 2450 | 89.09 | TRUE | FALSE |
| 1. Jasa Layanan | 1200 | 1080 | 90.00 | FALSE | TRUE |

#### Sheet: Peringatan
| tipe | pesan |
|---|---|
| warn | Realisasi Belanja Modal baru 62,50%... |
| ok   | Saldo kas cukup untuk 76 hari... |
| info | Data diperbarui setiap akhir hari... |

### Langkah 4 – Atur Akses Publik
1. Klik **Share** (Bagikan) di pojok kanan atas
2. Klik **Change to anyone with the link**
3. Set ke **Viewer** (Penampil)
4. Klik **Done**

> ⚠️ Jika Sheets tidak bisa dibaca publik, app akan otomatis pakai data demo.

---

## 🚀 TAHAP 3: Cara Menjalankan

### Opsi A – Buka Langsung
Klik 2x file `index.html` di browser. **Catatan:** Beberapa browser memblokir request ke Google Sheets dari file lokal (CORS).

### Opsi B – Jalankan Server Lokal (Direkomendasikan)
```bash
# Jika punya Python:
cd folder-dashboard
python -m http.server 8000
# Buka: http://localhost:8000

# Jika punya Node.js:
npx serve .
```

### Opsi C – Upload ke Hosting
Upload ketiga file ke: GitHub Pages, Netlify, Vercel, atau server web manapun.

---

## 🎛️ FITUR YANG TERSEDIA

| Fitur | Status |
|---|---|
| KPI Cards dengan indikator warna | ✅ |
| Trend chart pendapatan vs belanja | ✅ |
| Donut chart komposisi belanja | ✅ |
| Bar+Line chart realisasi anggaran | ✅ |
| Tabel per unit kerja + indikator | ✅ |
| Arus kas bar chart | ✅ |
| Rincian realisasi anggaran | ✅ |
| Peringatan & catatan otomatis | ✅ |
| Filter Tahun/Bulan/Unit | ✅ |
| Export ke Excel (.xlsx) | ✅ |
| Export PDF (Print) | ✅ |
| Auto-refresh data dari Sheets | ✅ |
| Fallback demo data | ✅ |
| Responsive layout | ✅ |

---

## 🔧 KUSTOMISASI

Edit di `app.js`:
- `SHEET_ID` → ID Google Sheets Anda
- `SHEETS` → Nama tab/sheet di Spreadsheet Anda

Edit di `style.css`:
- `:root { --clr-... }` → Ganti warna tema

---
*Dibuat untuk RSUP Fatmawati BLU – Dashboard Pemantauan Anggaran*
