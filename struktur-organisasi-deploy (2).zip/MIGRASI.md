# Catatan Migrasi (v1 ke v2)

Dokumen ini mencatat setiap migrasi: data, skema, berkas, dan perilaku. Setiap butir diberi nomor agar bisa dirujuk.

## Ringkasan langkah

Urutan migrasi lengkap: **001** (skema dasar v1, idempoten) lalu **002** (riwayat) lalu **003** (kapasitas). Nomor 001 sebelumnya tidak ada di paket; sejak v3.1.1 sudah ditambahkan. Nomor 002 dan 003 tidak diubah agar langkah yang sudah dijalankan tetap berlaku.

| No | Jenis | Wajib? | Dampak jika dilewati |
|---|---|---|---|
| M-01 | Skema database: tabel `riwayat` (`migrasi/002-riwayat.sql`) | Ya, bila memakai cloud | Riwayat tidak tercatat, dan penyimpanan akan gagal bila kode v2 dipasang tanpa tabel ini |
| M-02 | Berkas: unggah `core.js` bersama `index.html` dan `config.js` | Ya | Halaman kosong atau galat `OrgCore is not defined` |
| M-03 | Data daftar satuan | Tidak (otomatis) | Tidak ada. Daftar v1 tetap terbaca |
| M-04 | Diagram alur (kunci satuan) | Tidak (otomatis, bertahap) | Diagram tetap terbaca dengan kunci lama |
| M-05 | Pembersihan baris diagram yatim | Opsional | Hanya menambah ruang penyimpanan |
| M-06 | Angka tingkat organisasi berubah | Pemberitahuan | Angka di laporan lama tidak cocok lagi |
| M-07 | Penulisan kode tetap `{KODE}` | Opsional tetapi dianjurkan | Diagram tetap bisa putus bila nama satuan diubah |
| M-08 | Skema database: tabel `kapasitas` (`migrasi/003-kapasitas.sql`) | Ya, untuk v3 | Tab Kapasitas tidak bisa menyimpan ke cloud |
| M-09 | Urutan migrasi untuk instalasi v1 | Ya | Lihat bagian M-09 |

## M-01. Tambah tabel riwayat

Berkas: `migrasi/002-riwayat.sql`. Aman dijalankan berulang (`if not exists`, `drop policy if exists`). Tidak mengubah data v1.

Langkah:
1. Buka Supabase, lalu SQL Editor, lalu New query.
2. Tempel isi `migrasi/002-riwayat.sql`.
3. Ganti semua `GANTI-EMAIL-ADMIN` dengan email admin (gunakan Find and Replace).
4. Run.
5. Verifikasi: query di bagian akhir berkas harus mengembalikan tiga nama tabel (`struktur`, `alur`, `riwayat`).

Rollback (hanya bila ingin kembali ke v1; menghapus seluruh riwayat): lihat komentar di akhir berkas migrasi.

## M-02. Berkas aplikasi

v1 satu berkas `index.html` dengan `config.js`. v2 memakai tiga berkas: `index.html`, `core.js`, dan `config.js`. Ketiganya harus berada di folder yang sama di hosting.

Langkah di Hostinger: hPanel, File Manager, `public_html`. Unggah ketiga berkas. Berkas `index.html` v1 cukup ditimpa; `core.js` adalah berkas baru. `config.js` boleh diisi ulang dengan nilai yang sama seperti di v1.

Bila masih memakai `config.js` dari v1, isinya kompatibel dan tidak perlu diubah.

## M-03. Data daftar satuan

Format teks tidak berubah. Kode v2 membaca daftar v1 tanpa perubahan.

Kunci penyimpanan lokal (mode demo) berubah dari `org2` ke `org3`. Saat pertama kali dibuka, v2 membaca `org3` bila ada, lalu `org2`. Jadi draf lokal v1 tetap terbawa.

Kunci `col2` (status ciut atau buka) tidak berubah.

## M-04. Diagram alur

Di v1, diagram disimpan dengan kunci hash dari jalur nama satuan (misalnya `u1abc`). Di v2 setiap satuan punya kunci tetap:
- Satuan yang diberi kode `{KODE}`: kunci `c-KODE`.
- Satuan tanpa kode: tetap memakai kunci hash lama.

Aturan pembacaan: v2 mencari kunci baru dulu, lalu kunci lama. Jadi:
- Diagram v1 untuk satuan yang belum diberi kode tetap terbaca.
- Setelah satuan diberi kode, diagram lama tetap terbaca dan langsung tersimpan di kunci baru saat diubah.

Diagram di kunci lama tidak dihapus otomatis. Ini disengaja agar tidak ada data yang hilang.

## M-05. Pembersihan baris diagram yatim (opsional)

Setelah satuan diberi kode dan diagramnya sudah disalin ke kunci baru, baris lama bisa dibersihkan. Langkah aman: cari dulu, hapus kemudian.

Cari baris yang kunci-nya tidak lagi dipakai oleh satuan mana pun. Daftar kunci yang aktif bisa diambil dari tab Analisis (ekspor CSV, lalu hitung kode `c-...`). Hapus hanya setelah Anda yakin. Lakukan di SQL Editor dengan kondisi `kunci = '...'` untuk setiap baris, bukan dengan hapus massal.

## M-06. Angka tingkat organisasi berubah

Di v1, "tingkat" dihitung dari jumlah kolom tampilan, sehingga kelompok (`# Tim Kerja`, `# Instalasi`) ikut dihitung. Di v2, tingkat dihitung dari jumlah satuan induk.

Pada data default:
- v1: 4 tingkat.
- v2: 3 tingkat (tingkat 1: 1 satuan, tingkat 2: 12 satuan, tingkat 3: 47 satuan).

Angka "satuan kerja" tetap 55 (tidak menghitung direktorat), sama seperti v1.

Bila angka lama sudah dipakai di dokumen lain, sebutkan bahwa definisinya sudah diperbaiki.

## M-07. Penulisan kode tetap

Kode ditulis di akhir nama, sebelum tanda `|`:

    Instalasi Farmasi {IFA} | Budi Santoso

Aturan kode: huruf, angka, titik, garis bawah, atau tanda hubung; 1 sampai 20 karakter; unik untuk setiap satuan. Kode ganda dilaporkan sebagai galat di tab Analisis.

Saran isi kode: gunakan kode unit organisasi dari sistem kepegawaian bila tersedia, agar mudah dicocokkan dengan data resmi. Pastikan dulu aturan penomoran yang berlaku di instansi Anda.

Impor spreadsheet: tambahkan kolom kelima berjudul `Kode` (opsional).

## Data yang TIDAK dimigrasi otomatis

- Tidak ada akun baru. Akun admin Supabase tetap.
- Tidak ada perubahan pada kebijakan RLS selain menambah kebijakan untuk tabel `riwayat`.
- Riwayat perubahan sebelum v2 tidak ada, karena v1 tidak mencatatnya.

## M-08. Tambah tabel kapasitas (v3)

Berkas: `migrasi/003-kapasitas.sql`. Prasyarat: `migrasi/002-riwayat.sql` sudah dijalankan. Aman dijalankan berulang.

Langkah sama seperti M-01: tempel di SQL Editor, ganti `GANTI-EMAIL-ADMIN` dengan email admin, lalu Run. Tidak mengubah data v1 atau v2. Rollback ada di komentar akhir berkas.

Data tidak dimigrasi dari sumber lain. Tabel dimulai kosong, lalu diisi lewat tab Kapasitas.

## M-09. Urutan migrasi untuk setiap kondisi

- **Instalasi v1 yang berjalan:** jalankan 002, lalu 003, lalu unggah tiga berkas v3 (`index.html`, `core.js`, `config.js`).
- **Instalasi v2 yang berjalan:** jalankan 003, lalu unggah tiga berkas v3.
- **Instalasi baru:** jalankan `schema.sql` saja. Tabel `riwayat` dan `kapasitas` sudah termasuk.

Setelah migrasi, buka halaman dan masuk. Kalau tab Kapasitas memunculkan galat saat menyimpan, periksa apakah tabel `kapasitas` sudah ada di Table Editor Supabase.

## M-10. Perubahan pada uji regresi (tidak memengaruhi aplikasi)

Uji regresi di `tests/test.js` sekarang membaca `tests/fixtures/v1-index.html`, bukan `../../src/index.html`. Ini hanya memengaruhi pengujian, bukan aplikasi.

## M-11. Pemutakhiran ke v3.1 (tanpa perubahan basis data)

Skema tidak berubah. Dari v3.0 cukup unggah ulang berkas aplikasi. Perubahannya:
- Berkas baru `app.js`. Sekarang ada empat berkas yang harus diunggah bersama: `index.html`, `core.js`, `app.js`, dan `config.js`.
- `index.html` lama yang masih berisi skrip inline tidak perlu disimpan. Timpa dengan versi baru.

Di Vercel, unggah ulang melalui GitHub akan otomatis memperbarui situs. Di Hostinger, unggah keempat berkas ke `public_html`.

Setelah pemutakhiran, lakukan uji RLS sesuai `TESTING_RLS.md` sebelum data nyata dimasukkan.

## M-12. Migrasi 001 (skema dasar v1), ditambahkan di v3.1.1

Berkas: `migrasi/001-dasar-v1.sql`. Isinya sama dengan skema dasar v1 (`struktur`, `alur`, RLS, dan kebijakan admin), ditulis dengan `if not exists` dan `drop policy if exists` sehingga aman dijalankan ulang.

- Instalasi v1 yang sudah berjalan: tidak perlu menjalankannya. Lanjutkan dari 002 jika belum, lalu 003.
- Instalasi yang belum punya tabel `struktur` dan `alur`: jalankan 001, lalu 002, lalu 003. Atau cukup `schema.sql` untuk instalasi baru.
- Jangan lupa mengganti `GANTI-EMAIL-ADMIN` di berkas ini juga.
