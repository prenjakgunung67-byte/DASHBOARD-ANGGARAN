# Blue Print: Struktur Organisasi dan Alur Kerja

Versi dokumen: 2.0 (19 November 2026). Lingkup: RSUP Fatmawati, dimulai dari satuan kerja di tingkat direktorat sampai instalasi, unit, dan departemen.

## 1. Tujuan

Organisasi membutuhkan satu sumber kebenaran tentang siapa berada di mana, siapa memimpin siapa, dan bagaimana sebuah proses berjalan dari awal sampai selesai. Blue print ini mengarahkan pengembangan aplikasi agar:

1. Struktur organisasi selalu mutakhir dan mudah dipahami oleh pimpinan maupun pegawai.
2. Alur kerja (SOP) divisualisasikan dan terhubung ke satuan yang bertanggung jawab.
3. Tata kelola dapat diaudit: setiap perubahan tercatat.
4. Data struktur dapat dianalisis untuk keputusan SDM dan penataan organisasi.
5. Dapat dipakai tanpa biaya langganan besar dan tanpa keahlian teknis khusus.

## 2. Prinsip

- **Satu sumber kebenaran.** Daftar satuan kerja adalah satu-satunya sumber. Bagan, analisis, dan CSV dihasilkan dari sana.
- **Kode tetap, bukan nama.** Satuan dikenali dari kode, sehingga perubahan nama tidak merusak keterkaitan.
- **Sederhana dulu.** Teks biasa untuk menyusun struktur. Pengguna yang tidak teknis bisa mengedit tanpa pelatihan panjang.
- **Tidak menghilangkan data.** Perubahan struktur tidak pernah menghapus diagram atau riwayat lama secara otomatis.
- **Sesuai data resmi.** Aplikasi ini melengkapi, bukan menggantikan, sistem kepegawaian resmi (lihat bagian 8).

## 3. Pemangku kepentingan

| Peran | Kebutuhan utama | Yang dilakukan di aplikasi |
|---|---|---|
| Direktur Utama dan Direksi | Gambaran utuh, rentang kendali, kelengkapan pejabat | Melihat bagan, tab Analisis, ekspor |
| Tim Kerja Organisasi dan SDM | Akurasi struktur, riwayat, bahan penataan | Mengelola daftar, impor, CSV, riwayat |
| Pejabat satuan | Nama dan tugas satuannya benar | Memastikan pejabat tercatat, memperbarui diagram alur |
| Komite dan Satuan Pemeriksaan Internal | Bukti tata kelola dan jejak perubahan | Membaca riwayat dan temuan |
| Tim Perencanaan dan Anggaran | Basis untuk analisis beban kerja | Mengambil daftar satuan (CSV) |
| Pegawai | Tahu ke mana harus bertanya | Melihat bagan (hanya baca, saat dibuka secara terbatas) |

Catatan: peran pembaca belum tersedia di v2. Lihat peta jalan fase 1.

## 4. Kapabilitas bisnis

| Kode | Kapabilitas | Status v2 |
|---|---|---|
| K1 | Menyusun dan memelihara daftar satuan kerja | Tersedia |
| K2 | Visualisasi bagan organisasi, lipat dan buka, cari, cetak, SVG | Tersedia |
| K3 | Diagram alur kerja (SOP visual) per satuan | Tersedia |
| K4 | Rincian satuan: pejabat, jalur induk, bawahan langsung | Tersedia |
| K5 | Analisis struktur dan temuan perbaikan | Tersedia (dasar) |
| K6 | Ekspor data (CSV untuk Excel, SVG untuk dokumen) | Tersedia |
| K7 | Jejak audit perubahan | Tersedia (dasar, tanpa persetujuan) |
| K8 | Peran pengguna dan persetujuan berjenjang | Belum |
| K9 | Versi struktur per tanggal SK | Belum |
| K10 | Formasi dan kebutuhan pegawai per satuan | Belum |
| K11 | Integrasi dengan sistem kepegawaian dan SIMRS | Belum |

## 5. Proses bisnis utama: perubahan struktur

1. **Usulan.** Pejabat atau Tim Kerja Organisasi dan SDM menyiapkan perubahan (satuan baru, penggabungan, perubahan induk, pergantian pejabat).
2. **Verifikasi.** Tim Kerja Organisasi dan SDM memeriksa dasar hukum dan dampaknya. Di aplikasi: tab Analisis menunjukkan dampak (rentang kendali, satuan tanpa pejabat, kode ganda).
3. **Persetujuan.** Pimpinan menyetujui sesuai jenjang. Di v2 belum ada persetujuan elektronik; saat ini dilakukan di luar aplikasi dengan naskah dinas.
4. **Penerbitan.** Daftar di aplikasi diperbarui setelah SK terbit. Perubahan tercatat di riwayat.
5. **Penyebaran.** Bagan dan CSV diekspor dan dibagikan. Untuk jangka panjang, versi per SK disimpan (fase 1).
6. **Tindak lanjut.** Diagram alur satuan baru dibuat; kode disesuaikan dengan sistem kepegawaian.

## 6. Proses bisnis: pemeliharaan rutin

- Setiap bulan: periksa tab Analisis, tindak lanjuti temuan galat dan peringatan.
- Setiap pergantian pejabat: perbarui kolom pejabat dan cek riwayat.
- Setiap minggu (bila memakai paket Free): buka aplikasi agar proyek tidak dijeda.
- Setiap triwulan: unduh CSV dan SVG sebagai cadangan.

## 7. Peta jalan

**Fase 0. Stabilisasi (selesai pada v2).** Kode tetap, analisis, rincian satuan, ekspor, riwayat, pengujian otomatis, dan migrasi terdokumentasi.

**Fase 1. Tata kelola (perkiraan 4 sampai 6 minggu kerja).**
- Peran pengguna: admin, editor (hanya satuan tertentu), dan pembaca.
- Alur status perubahan: draf, diajukan, disetujui, terbit. Hanya yang terbit yang tampil di bagan publik internal.
- Snapshot versi per tanggal SK, dengan kolom nomor dan tanggal SK pada setiap versi.
- Pejabat dengan periode jabatan (mulai dan berakhir), sehingga dapat diingatkan saat jabatan hampir habis.
- Pindahkan skrip inline ke berkas JavaScript tersendiri agar dapat dipasang Content Security Policy yang ketat.

**Fase 2. Integrasi SDM (perkiraan 6 sampai 8 minggu kerja).**
- Formasi dan jumlah pegawai per satuan (jabatan fungsional, perawat, bidan, tenaga penunjang).
- Hubungkan satuan ke analisis beban kerja (ABK) berbasis BOR yang sedang disusun. Kode satuan menjadi kunci penghubung.
- Dashboard rasio: formasi terisi, kebutuhan, dan selisih per satuan.
- Impor data pegawai dari sumber resmi (berkas ekspor) dengan validasi.

**Fase 3. Integrasi digital (bergantung pada akses dan kebijakan).**
- Sinkronisasi kode unit organisasi dengan sistem kepegawaian nasional.
- Tautan ke dokumen mutu dan SOP yang berlaku.
- Pertimbangan integrasi dengan SIMRS atau sistem informasi kesehatan bila tersedia antarmuka resmi.

## 8. Dasar regulasi dan data resmi

Aplikasi ini adalah alat kerja internal. Data resmi tetap berada di sistem yang ditetapkan pemerintah. Hal-hal yang perlu diverifikasi oleh tim hukum atau organisasi sebelum dijadikan acuan:

- **Permenkes 26 Tahun 2022** tentang organisasi dan tata kerja rumah sakit di lingkungan Kementerian Kesehatan. Mengatur rumah sakit vertikal sebagai UPT. Perlu dipastikan status berlakunya.
- **Permenkes 6 Tahun 2026** tentang rumah sakit (berlaku sejak 12 Juni 2026). Menyatakan mencabut dan menggantikan sejumlah peraturan lama, termasuk aturan sistem informasi rumah sakit. Perlu dicek dampaknya pada organisasi dan pelaporan.
- **Sistem kepegawaian BKN (SIASN, MyASN, ASN Digital)** sebagai sumber data resmi kepegawaian ASN.
- **Kode unit organisasi (unor)** dalam sistem kepegawaian. Kode ini perlu cocok dengan kode di aplikasi bila ingin sinkron.

## 9. Indikator keberhasilan (KPI)

| Indikator | Sasaran awal | Cara ukur |
|---|---|---|
| Satuan dengan pejabat tercatat | 100% | Tab Analisis, kartu "Pejabat belum diisi" |
| Satuan dengan kode tetap | 100% | Kartu "Belum ber-kode" |
| Satuan dengan diagram alur | Sesuai prioritas (mulai dari layanan utama) | Kartu "Belum ada diagram alur" |
| Galat kode ganda dan nama ganda | 0 | Tab Analisis, kelompok temuan merah |
| Rentang kendali di atas acuan | Tinjau setiap satuan yang melebihi 12 bawahan | Tab Analisis, kelompok "Rentang kendali lebar" |
| Jeda perubahan struktur ke aplikasi | Maksimal 5 hari kerja setelah SK terbit | Tanggal di riwayat dibanding tanggal SK |
| Cadangan terakhir | Maksimal 30 hari | Tanggal unduhan CSV terakhir |

## 10. Risiko dan mitigasi

| Risiko | Dampak | Mitigasi |
|---|---|---|
| Proyek Supabase Free dijeda karena tidak aktif | Aplikasi tidak bisa diakses sementara | Buka mingguan; pemulihan hingga 90 hari; pertimbangkan paket berbayar bila operasional kritis |
| Data hilang karena tidak ada cadangan harian | Kehilangan struktur | Ekspor CSV dan SVG berkala; simpan di tempat terpisah |
| Satu admin menjadi titik tunggal | Tidak ada yang bisa mengedit saat admin tidak tersedia | Tambah akun editor pada fase 1; catat kredensial di tempat aman |
| Perubahan nama memutus diagram | Diagram tampak hilang | Kode tetap (sudah tersedia); analisis menandai satuan tanpa kode |
| Kode tidak sesuai data resmi | Laporan tidak cocok | Tetapkan aturan kode bersama Tim Kerja Organisasi dan SDM |
| Regulasi berubah | Struktur tidak sesuai ketentuan | Tinjau regulasi setiap perubahan; catat dasar hukum di riwayat (fase 1) |
| Data pribadi pejabat terpapar | Pelanggaran privasi | Aturan RLS aktif; kunci anon tidak memberi akses tulis tanpa login admin |

## 11. Batasan dokumen ini

- Dokumen ini disusun dari berkas usulan dasar dan analisis data default. Belum ada data struktur sungguhan yang diuji.
- Regulasi yang disebut di bagian 8 perlu diverifikasi ulang ke sumber resmi sebelum dijadikan dasar keputusan.
- Angka sasaran KPI adalah usulan awal untuk disepakati.
