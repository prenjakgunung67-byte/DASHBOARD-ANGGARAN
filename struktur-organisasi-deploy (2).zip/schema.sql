-- Struktur Organisasi dan Alur Kerja v3
-- Instalasi BARU. Untuk instalasi v1 yang sudah berjalan, jalankan migrasi/002-riwayat.sql lalu migrasi/003-kapasitas.sql.
-- Untuk instalasi v2, jalankan migrasi/003-kapasitas.sql saja.
-- Jalankan di Supabase: SQL Editor > New query > Run
-- GANTI semua tulisan GANTI-EMAIL-ADMIN dengan email admin (gunakan Find and Replace di editor).

create table if not exists struktur (
  id int primary key default 1 check (id = 1),
  teks text not null default '',
  diubah timestamptz not null default now()
);

create table if not exists alur (
  kunci text primary key,
  isi jsonb not null,
  diubah timestamptz not null default now()
);

create table if not exists riwayat (
  id bigint generated always as identity primary key,
  waktu timestamptz not null default now(),
  jenis text not null,
  ringkas text not null default '',
  pengguna text not null default ''
);

create index if not exists riwayat_waktu_idx on riwayat (waktu desc);

create table if not exists kapasitas (
  id int primary key default 1 check (id = 1),
  isi jsonb not null default '{"rows": []}'::jsonb,
  diubah timestamptz not null default now()
);

alter table struktur enable row level security;
alter table alur enable row level security;
alter table riwayat enable row level security;
alter table kapasitas enable row level security;

-- Hanya akun dengan email admin yang boleh membaca dan menulis.
drop policy if exists "admin struktur" on struktur;
create policy "admin struktur" on struktur for all to authenticated
  using ((auth.jwt() ->> 'email') = 'GANTI-EMAIL-ADMIN')
  with check ((auth.jwt() ->> 'email') = 'GANTI-EMAIL-ADMIN');

drop policy if exists "admin alur" on alur;
create policy "admin alur" on alur for all to authenticated
  using ((auth.jwt() ->> 'email') = 'GANTI-EMAIL-ADMIN')
  with check ((auth.jwt() ->> 'email') = 'GANTI-EMAIL-ADMIN');

drop policy if exists "admin riwayat" on riwayat;
create policy "admin riwayat" on riwayat for all to authenticated
  using ((auth.jwt() ->> 'email') = 'GANTI-EMAIL-ADMIN')
  with check ((auth.jwt() ->> 'email') = 'GANTI-EMAIL-ADMIN');

drop policy if exists "admin kapasitas" on kapasitas;
create policy "admin kapasitas" on kapasitas for all to authenticated
  using ((auth.jwt() ->> 'email') = 'GANTI-EMAIL-ADMIN')
  with check ((auth.jwt() ->> 'email') = 'GANTI-EMAIL-ADMIN');
