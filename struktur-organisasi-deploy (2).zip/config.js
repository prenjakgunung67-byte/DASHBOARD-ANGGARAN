// Isi dengan data dari Supabase: Project Settings > API
window.APP_CONFIG={
  SUPABASE_URL:'GANTI-DENGAN-PROJECT-URL',
  SUPABASE_ANON_KEY:'GANTI-DENGAN-ANON-KEY'
};
