# Struktur Organisasi dan Alur Kerja (v3.1)

Aplikasi web statis untuk menyusun dan menganalisis struktur organisasi serta diagram alur kerja. Dibuat untuk Rumah Sakit Umum Pusat Fatmawati. Satu admin. Basis data dan login memakai Supabase.

## Isi paket

| Berkas | Fungsi |
|---|---|
| `index.html` | Antarmuka utama (tiga tab: Struktur, Alur, Analisis) |
| `core.js` | Logika murni: penguraian daftar, analisis, impor, ekspor CSV, cadangan |
| `assets/rsf.png` | Logo Kemenkes RS Fatmawati (halaman masuk, header, ikon tab) |
| `app.js` | Antarmuka dan sinkronisasi cloud (dipisah dari HTML agar CSP ketat bisa dipasang) |
| `config.js` | Kunci Supabase (kosongkan untuk mode demo) |
| `schema.sql` | Skema basis data untuk instalasi baru |
| `migrasi/001-dasar-v1.sql` | Skema dasar v1 (idempoten). Hanya bila tabel struktur atau alur belum ada |
| `migrasi/002-riwayat.sql` | Migrasi riwayat untuk instalasi v1 |
| `migrasi/003-kapasitas.sql` | Migrasi tabel kapasitas (v3) |
| `tests/test.js` | Uji unit logika, modul kapasitas, dan uji regresi terhadap v1 |
| `tests/ui-test.js` | Uji antarmuka (jsdom): demo, migrasi, mode cloud, dan kapasitas |
| `tests/fixtures/v1-index.html` | Salinan v1 untuk uji regresi |
| `TESTING_RLS.md` | Panduan uji RLS dengan akun non-admin (wajib sebelum data nyata) |
| `BLUEPRINT.md` | Blue print bisnis dan solusi |
| `RANCANGAN_TEKNIS.md` | Rancangan teknis untuk programmer |
| `ANALISIS_DAN_REKOMENDASI.md` | Analisis usulan, perbandingan aplikasi, dan rekomendasi kerja |
| `CHANGELOG.md` | Catatan perubahan |
| `MIGRASI.md` | Catatan migrasi |
| `HASIL_UJI.md` | Hasil uji pada saat paket ini dibuat |
| `pratinjau/` | Tangkapan layar tampilan |

## Pasang baru

1. Buat proyek di supabase.com (paket Free). Catat kata sandi basis data.
2. SQL Editor: tempel `schema.sql`, ganti semua `GANTI-EMAIL-ADMIN` dengan email admin, lalu Run.
3. Authentication, Users, Add user: buat pengguna admin dan centang auto-confirm.
4. Authentication, Sign In / Providers: matikan *Allow new users to sign up*.
5. Project Settings, API: salin *Project URL* dan kunci *anon public* ke `config.js`.
6. Unggah `index.html`, `core.js`, `app.js`, `config.js`, dan folder `assets/` ke hosting (misalnya Hostinger, `public_html`).
7. Lakukan uji RLS sesuai `TESTING_RLS.md` sebelum memasukkan data nyata.
8. Buka alamat situs dan masuk dengan email admin.

Tanpa mengisi `config.js`, aplikasi berjalan dalam mode demo: tanpa login, data hanya tersimpan di browser.

## Pemutakhiran dari v1

Ikuti `MIGRASI.md` (M-09 dan M-11). Urutan lengkap: `001-dasar-v1.sql` (hanya bila belum ada tabelnya), lalu `002-riwayat.sql`, lalu `003-kapasitas.sql`. Dari v1: mulai dari 002. Dari v2: cukup 003. Setelah itu unggah tiga berkas aplikasi.

## Cara mengisi data kapasitas (v3)

Di tab Kapasitas, tempel data dari Excel dengan kolom berurutan: Gedung, Kode ruangan, Nama ruangan, Kode instalasi, Kelas, TT, Berlaku sejak, No. SK. Tanggal berlaku ditulis YYYY-MM-DD. Untuk perubahan jumlah TT, tambahkan baris baru dengan kode ruangan yang sama dan tanggal berlaku yang baru. Aplikasi memakai versi terbaru yang sudah berlaku pada tanggal yang dipilih.

## Cara penulisan daftar

- Satu baris satu satuan. Menjorok dua spasi berarti berada di bawah baris di atasnya.
- `| Nama pejabat` di akhir baris (opsional).
- `# Nama` untuk kelompok jenis, misalnya `# Instalasi`. Kelompok tidak dihitung sebagai satuan.
- `{KODE}` untuk kode tetap satuan, misalnya `Instalasi Farmasi {IFA}`. Dianjurkan untuk semua satuan.

## Menjalankan pengujian

Membutuhkan Node.js 18 atau lebih baru. Uji antarmuka memakai jsdom, yang dipasang oleh `npm install`.

    npm install
    npm test

## Cadangan

Tab Analisis, tombol "Unduh cadangan (JSON)", menyimpan seluruh data. Simpan berkasnya di tempat terpisah, misalnya Google Drive atau hard disk, setiap bulan. Pemulihan lewat "Pulihkan dari cadangan" meminta konfirmasi dan memeriksa isi berkas terlebih dahulu.

## Perlu diketahui

- Proyek Supabase paket Free dijeda otomatis bila tidak ada aktivitas selama 7 hari. Buka aplikasi minimal seminggu sekali. Proyek yang dijeda dapat dipulihkan dari dashboard (tersedia sampai 90 hari).
- Paket Free tidak punya cadangan harian. Unduh CSV dan SVG secara berkala dan simpan di tempat lain. Riwayat perubahan ada di tab Analisis.
- Kunci *anon* memang terlihat di browser. Datanya dilindungi oleh aturan RLS di basis data, jadi jangan lewati langkah pemasangan RLS.
- Tabel `riwayat` akan terus bertambah. Pada skala organisasi ini ukurannya kecil, tetapi pertimbangkan kebijakan penyimpanan jika sudah lama dipakai.
