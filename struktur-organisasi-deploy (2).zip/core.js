/* core.js: logika murni aplikasi Struktur Organisasi (tanpa DOM).
   Dipakai oleh index.html dan oleh tests/test.js. */
(function (global, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else global.OrgCore = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // Kode tetap satuan, ditulis di akhir nama: "Instalasi Farmasi {IFA}"
  const CODE_RE = /\s*\{([A-Za-z0-9._-]{1,20})\}\s*$/;
  // Pedoman rentang kendali (jumlah bawahan langsung). Ini acuan, bukan aturan baku.
  const SPAN_WARN = 12;

  const DEFAULT_OUTLINE = [
    'Direktorat Utama',
    '  Direktorat Medik dan Keperawatan',
    '    # Tim Kerja',
    '      Tim Kerja Pelayanan Medik',
    '      Tim Kerja Pelayanan Keperawatan',
    '      Tim Kerja Pelayanan Penunjang',
    '    # Instalasi',
    '      Instalasi Gawat Darurat',
    '      Instalasi Rawat Jalan',
    '      Instalasi Rawat Inap',
    '      Instalasi Rehabilitasi Medik',
    '      Instalasi Bedah Sentral',
    '      Instalasi Intensif',
    '      Instalasi Radiologi Terpadu',
    '      Instalasi Laboratorium',
    '      Instalasi Forensik dan Pemulasaraan Jenazah',
    '      Instalasi Farmasi',
    '      Instalasi Gizi',
    '    # Unit',
    '      Unit Transplantasi Organ dan Jaringan',
    '      Unit Pengelola Darah',
    '      Unit Dialisis',
    '      Unit Kardiovaskuler Intervensi',
    '      Unit Cancer Center',
    '    # Departemen',
    '      Departemen Ortopedi',
    '      Departemen Uro-Nefrologi',
    '      Departemen Onkologi',
    '      Departemen Medik',
    '      Departemen Anestesi',
    '      Departemen Kardiovaskular',
    '      Departemen Kulit dan Estetika',
    '      Departemen Ibu dan Anak',
    '      Departemen Bedah',
    '      Departemen Neurologi',
    '      Departemen Penunjang',
    '      Departemen Gastroenterologi',
    '  Direktorat SDM, Pendidikan dan Penelitian',
    '    # Tim Kerja',
    '      Tim Kerja Organisasi dan SDM',
    '      Tim Kerja Pendidikan dan Pelatihan',
    '    # Instalasi',
    '      Instalasi Pengelolaan Inovasi dan Kekayaan Intelektual',
    '    # Unit',
    '      Unit Fungsional Pendidikan',
    '      Clinical Research Unit',
    '  Direktorat Perencanaan dan Keuangan',
    '    # Tim Kerja',
    '      Tim Kerja Perencanaan dan Evaluasi Program',
    '      Tim Kerja Perencanaan Anggaran',
    '      Tim Kerja Pelaksanaan Keuangan',
    '      Tim Kerja Akuntansi dan Barang Milik Negara',
    '    # Instalasi',
    '      Instalasi Rekam Medik dan Administrasi Penjaminan Pasien',
    '  Direktorat Layanan Operasional',
    '    # Tim Kerja',
    '      Tim Kerja Tata Usaha dan Rumah Tangga',
    '      Tim Kerja Hukum, Hubungan Masyarakat, Promosi Kesehatan dan Pemasaran',
    '    # Instalasi',
    '      Instalasi Kesehatan Lingkungan dan Keselamatan dan Kesehatan Kerja (K3) Rumah Sakit',
    '      Instalasi Sistem Informasi Manajemen Rumah Sakit',
    '      Instalasi Pemeliharaan Sarana dan Prasarana Rumah Sakit',
    '      Instalasi Sterilisasi Sentral dan Binatu',
    '  # Komite',
    '    Komite Medik',
    '    Komite Keperawatan dan Tenaga Kesehatan Lain',
    '    Komite Mutu Rumah Sakit',
    '    Komite Pencegahan dan Pengendalian Infeksi',
    '    Komite Etik Penelitian',
    '  Satuan Pemeriksaan Internal',
    '  # Unit',
    '    Unit Layanan Pengadaan',
    '    Unit Pengembangan Usaha'
  ].join('\n');

  const EXAMPLE_FLOW = {
    n: [
      { id: 1, x: 400, y: 30, t: 'Mulai', k: 'start' },
      { id: 2, x: 400, y: 120, t: 'Isi formulir', k: 'proc' },
      { id: 3, x: 400, y: 220, t: 'Data lengkap?', k: 'dec' },
      { id: 4, x: 400, y: 370, t: 'Proses persetujuan', k: 'proc' },
      { id: 5, x: 400, y: 470, t: 'Selesai', k: 'start' },
      { id: 6, x: 720, y: 120, t: 'Kembali ke pemohon', k: 'proc' }
    ],
    e: [
      { a: 1, b: 2, l: '' }, { a: 2, b: 3, l: '' }, { a: 3, b: 4, l: 'Ya' },
      { a: 4, b: 5, l: '' }, { a: 3, b: 6, l: 'Tidak' }, { a: 6, b: 2, l: '' }
    ]
  };

  /* Hash lama (v1). Harus tetap sama agar diagram lama bisa dibaca. */
  function hid(s) {
    let h = 7;
    for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0;
    return 'u' + h.toString(36);
  }

  function eachNode(n, fn) {
    fn(n);
    n.c.forEach(c => eachNode(c, fn));
  }

  /* Urai teks daftar menjadi pohon. Setiap baris menyimpan nomor barisnya. */
  function parseOutline(txt) {
    const top = { t: '', o: '', c: [], k: '', g: false, code: '', line: -1 };
    const stack = [{ n: top, d: -1 }];
    String(txt || '').split('\n').forEach((raw, i) => {
      if (!raw.trim()) return;
      const d = Math.floor(raw.match(/^ */)[0].length / 2);
      const parts = raw.trim().split('|');
      let name = parts[0].trim();
      const o = parts.slice(1).join('|').trim();
      const g = name.startsWith('# ');
      if (g) name = name.slice(2).trim();
      let code = '';
      const m = g ? null : name.match(CODE_RE);
      if (m) { code = m[1]; name = name.slice(0, m.index).trim(); }
      if (!name) return;
      while (stack.at(-1).d >= d) stack.pop();
      const p = stack.at(-1).n;
      const n = { t: name, o, c: [], k: p.k + '/' + name, g, code, line: i };
      p.c.push(n);
      stack.push({ n, d });
    });
    const root = top.c.length === 1 ? top.c[0]
      : Object.assign(top, { t: 'Organisasi', k: '/Organisasi', virtual: true });
    eachNode(root, n => {
      if (n.g || n.virtual) return;
      n.legacy = hid(n.k);
      n.id = n.code ? 'c-' + n.code : n.legacy;
    });
    return root;
  }

  /* Telusuri satuan (bukan kelompok).
     depth = kolom tampilan (kelompok ikut menambah kolom);
     tier  = tingkat organisasi (jumlah satuan induk + 1; kelompok TIDAK menambah tingkat);
     parent = satuan induk langsung; group = nama kelompok terdekat, jika ada. */
  function eachUnit(root, fn) {
    const visit = (n, depth, tier, parent, group) => {
      if (n.g) { n.c.forEach(c => visit(c, depth + 1, tier, parent, n.t)); return; }
      fn(n, { depth, tier, parent, group });
      n.c.forEach(c => visit(c, depth + 1, tier + 1, n, ''));
    };
    if (root.virtual) root.c.forEach(c => visit(c, 0, 0, null, ''));
    else visit(root, 0, 0, null, '');
  }

  /* Bawahan langsung: satuan di bawah n, termasuk yang berada dalam kelompok. */
  function directUnits(n) {
    const out = [];
    const rec = x => x.c.forEach(c => (c.g ? rec(c) : out.push(c)));
    rec(n);
    return out;
  }

  function findByPath(root, k) {
    let hit = null;
    eachNode(root, n => { if (!hit && n.k === k) hit = n; });
    return hit;
  }

  /* Analisis struktur. flowIds = Set berisi kunci diagram alur yang tersimpan. */
  function analyze(root, flowIds) {
    const has = n => !!flowIds && (flowIds.has(n.id) || flowIds.has(n.legacy));
    const names = new Map();
    const codes = new Map();
    const issues = [];
    const spans = [];
    const byLevel = [];
    const units = [];
    let groups = 0, directorates = 0, maxDepth = 0, leaves = 0, noOfficer = 0, noFlow = 0, noCode = 0;

    eachNode(root, n => { if (n.g) groups++; });
    eachUnit(root, (n, info) => {
      units.push({ n, depth: info.tier });
      maxDepth = Math.max(maxDepth, info.tier);
      byLevel[info.tier] = (byLevel[info.tier] || 0) + 1;
      if (/^Direktorat/i.test(n.t)) directorates++;
      names.set(n.t, [...(names.get(n.t) || []), n]);
      if (n.code) codes.set(n.code, [...(codes.get(n.code) || []), n]);
      else noCode++;
      if (!n.o) noOfficer++;
      if (!has(n)) noFlow++;
      const subs = directUnits(n).length;
      if (subs) spans.push(subs); else leaves++;
    });

    for (const [name, arr] of names) {
      if (arr.length > 1) arr.forEach(n => issues.push({ sev: 'error', kind: 'dup-name', text: `Nama "${name}" dipakai ${arr.length} kali`, node: n }));
    }
    for (const [code, arr] of codes) {
      if (arr.length > 1) arr.forEach(n => issues.push({ sev: 'error', kind: 'dup-code', text: `Kode {${code}} dipakai ${arr.length} satuan`, node: n }));
    }
    for (const { n } of units) {
      if (!n.o) issues.push({ sev: 'info', kind: 'no-officer', text: 'Pejabat belum diisi', node: n });
      const subs = directUnits(n).length;
      if (subs > SPAN_WARN) issues.push({ sev: 'warn', kind: 'wide-span', text: `${subs} bawahan langsung (di atas ${SPAN_WARN})`, node: n });
      if (subs === 1) issues.push({ sev: 'info', kind: 'single-sub', text: 'Hanya 1 bawahan langsung; pertimbangkan penggabungan', node: n });
      if (!n.code) issues.push({ sev: 'info', kind: 'no-code', text: 'Belum ada kode {…}; diagram alur bisa terputus bila nama diubah', node: n });
      if (!has(n)) issues.push({ sev: 'info', kind: 'no-flow', text: 'Belum punya diagram alur', node: n });
    }
    const order = { error: 0, warn: 1, info: 2 };
    issues.sort((a, b) => order[a.sev] - order[b.sev]);

    const sum = spans.reduce((s, x) => s + x, 0);
    return {
      units: units.length,
      groups,
      directorates,
      levels: units.length ? maxDepth + 1 : 0,
      byLevel: byLevel.map(x => x || 0),
      leaves,
      avgSpan: spans.length ? Math.round((sum / spans.length) * 10) / 10 : 0,
      maxSpan: spans.length ? Math.max(...spans) : 0,
      noOfficer,
      noFlow,
      noCode,
      issues,
      list: units
    };
  }

  /* Ubah baris spreadsheet (Satuan, Induk, Pejabat, Kelompok, Kode) menjadi teks daftar. */
  function importRows(text) {
    let rows = String(text || '').split('\n')
      .map(l => l.split(/\t|;/).map(s => s.trim()))
      .filter(r => r[0]);
    if (rows.length && /induk|parent/i.test(rows[0][1] || '')) rows = rows.slice(1);
    if (!rows.length) return '';
    const M = new Map();
    rows.forEach(r => {
      if (!M.has(r[0])) M.set(r[0], { t: r[0], o: r[2] || '', c: [], kel: r[3] || '', code: (r[4] || '').replace(/[{}]/g, '') });
    });
    const R = [];
    const seen = new Set();
    for (const r of rows) {
      if (seen.has(r[0])) continue;
      seen.add(r[0]);
      const n = M.get(r[0]);
      const p = r[1] && M.get(r[1]);
      const tg = p && p !== n ? p : null;
      if (tg && n.kel) {
        let gp = tg.c.find(x => x.g && x.t === n.kel);
        if (!gp) { gp = { t: n.kel, o: '', c: [], g: true }; tg.c.push(gp); }
        gp.c.push(n);
      } else (tg ? tg.c : R).push(n);
    }
    const out = [];
    const reached = new Set();
    const w = (n, d) => {
      reached.add(n);
      out.push('  '.repeat(d) + (n.g ? '# ' : '') + n.t + (n.code ? ' {' + n.code + '}' : '') + (n.o ? ' | ' + n.o : ''));
      n.c.forEach(c => w(c, d + 1));
    };
    R.forEach(n => w(n, 0));
    // Satuan yang tidak tercapai dari akar berarti ada lingkaran induk. Tolak, jangan diam-diam dibuang.
    const lost = [...M.values()].filter(n => !reached.has(n));
    if (lost.length) {
      throw new Error('Ada induk yang saling merujuk (lingkaran) pada: ' + lost.map(n => n.t).join(', '));
    }
    return out.join('\n');
  }

  /* Ekspor CSV untuk Excel (pemisah titik koma, BOM agar huruf Indonesia terbaca). */
  function toCsv(root) {
    const esc = v => '"' + String(v === undefined || v === null ? '' : v).replace(/"/g, '""') + '"';
    const rows = [['Kode', 'Satuan kerja', 'Induk', 'Pejabat', 'Kelompok', 'Tingkat', 'Bawahan langsung']];
    eachUnit(root, (n, info) => rows.push([
      n.code, n.t, info.parent ? info.parent.t : '', n.o, info.group, info.tier + 1, directUnits(n).length
    ]));
    return '\ufeff' + rows.map(r => r.map(esc).join(';')).join('\r\n');
  }

  /* Pilih kunci diagram yang dipakai: kunci baru jika ada, jika tidak kunci lama (v1). */
  function flowKeyFor(unit, keys) {
    if (keys && keys.has(unit.id)) return unit.id;
    if (keys && keys.has(unit.legacy)) return unit.legacy;
    return unit.id;
  }

  /* ===== Kapasitas tempat tidur (v3) =====
     Satu baris per ruangan per periode berlaku. Kolom:
     Gedung | Kode ruangan | Nama ruangan | Kode instalasi | Kelas | TT | Berlaku sejak | No. SK */
  const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
  const INT_RE = /^\d+$/;

  function csvEsc(v) { return '"' + String(v === undefined || v === null ? '' : v).replace(/"/g, '""') + '"'; }

  function parseRuangan(text, validInstalasi) {
    const issues = [], rows = [];
    let lines = String(text || '').split('\n')
      .map(l => l.split(/\t|;/).map(x => x.trim()))
      .filter(r => r.some(x => x));
    if (lines.length && (lines[0][0] || '').toLowerCase() === 'gedung') lines = lines.slice(1);
    const seen = new Set();
    lines.forEach((r, i) => {
      const no = i + 1;
      const row = {
        gedung: r[0] || '', kode: r[1] || '', nama: r[2] || '', kodeInst: r[3] || '',
        kelas: r[4] || '', tt: INT_RE.test(r[5] || '') ? Number(r[5]) : 0,
        berlaku: r[6] || '', sk: r[7] || ''
      };
      const err = t => issues.push({ sev: 'error', row: no, text: `Baris ${no}: ${t}` });
      if (!row.kode) err('kode ruangan kosong');
      if (!row.kodeInst) err('kode instalasi kosong');
      if (!INT_RE.test(r[5] || '')) err(`TT "${r[5] || ''}" bukan bilangan bulat`);
      if (!DATE_RE.test(row.berlaku)) err('tanggal berlaku harus berformat YYYY-MM-DD');
      const key = row.kode + '|' + row.berlaku;
      if (row.kode && seen.has(key)) err(`ruangan ${row.kode} dengan tanggal berlaku ${row.berlaku} muncul dua kali`);
      seen.add(key);
      if (validInstalasi && row.kodeInst && !validInstalasi.has(row.kodeInst))
        issues.push({ sev: 'warn', row: no, text: `Baris ${no}: kode instalasi ${row.kodeInst} belum ada di daftar organisasi` });
      if (row.kode) rows.push(row);
    });
    return { rows, issues, ok: !issues.some(x => x.sev === 'error') };
  }

  /* Ambil baris yang berlaku pada tanggal asOf (YYYY-MM-DD): untuk tiap ruangan, versi terbaru yang sudah berlaku. */
  function kapasitasAsOf(rows, asOf) {
    const latest = new Map();
    for (const r of rows) {
      if (r.berlaku > asOf) continue;
      const c = latest.get(r.kode);
      if (!c || r.berlaku > c.berlaku) latest.set(r.kode, r);
    }
    const aktif = [...latest.values()];
    const per = new Map();
    let total = 0;
    for (const r of aktif) {
      total += r.tt;
      per.set(r.kodeInst, (per.get(r.kodeInst) || 0) + r.tt);
    }
    const perInstalasi = [...per].map(([kode, tt]) => ({ kode, tt }))
      .sort((a, b) => b.tt - a.tt || a.kode.localeCompare(b.kode));
    return { total, ruangan: aktif.length, perInstalasi, aktif };
  }

  function cekTotal(total, expected) {
    return { ok: total === Number(expected), selisih: total - Number(expected) };
  }

  function kapasitasCsv(rows) {
    const out = [['Gedung', 'Kode ruangan', 'Nama ruangan', 'Kode instalasi', 'Kelas', 'TT', 'Berlaku sejak', 'No. SK']];
    rows.forEach(r => out.push([r.gedung, r.kode, r.nama, r.kodeInst, r.kelas, r.tt, r.berlaku, r.sk]));
    return '\ufeff' + out.map(r => r.map(csvEsc).join(';')).join('\r\n');
  }

  function ringkasanCsv(summary) {
    const out = [['Kode instalasi', 'TT operasional']];
    summary.perInstalasi.forEach(x => out.push([x.kode, x.tt]));
    out.push(['TOTAL', summary.total]);
    return '\ufeff' + out.map(r => r.map(csvEsc).join(';')).join('\r\n');
  }


  /* ===== Cadangan dan pemulihan (v3.1) ===== */
  const BACKUP_VERSI = '3.1.0';
  const KEY_RE = /^[A-Za-z0-9._-]{1,64}$/;
  const MAX_ROWS = 50000;
  const MAX_TEKS = 2000000;

  function buatCadangan(d) {
    return {
      aplikasi: 'struktur-organisasi',
      versi: BACKUP_VERSI,
      dibuat: d.dibuat || new Date().toISOString(),
      struktur: { teks: String(d.teks || '') },
      alur: d.alur || {},
      kapasitas: { rows: Array.isArray(d.rows) ? d.rows : [] },
      riwayat: Array.isArray(d.riwayat) ? d.riwayat : []
    };
  }

  function validasiCadangan(o) {
    const e = [];
    if (!o || typeof o !== 'object' || Array.isArray(o)) return { ok: false, errors: ['berkas bukan objek JSON'] };
    if (o.aplikasi !== 'struktur-organisasi') e.push('bukan berkas cadangan aplikasi ini');
    if (typeof o.versi !== 'string') e.push('versi tidak ada');
    if (!o.struktur || typeof o.struktur.teks !== 'string') e.push('struktur.teks harus berupa teks');
    else if (o.struktur.teks.length > MAX_TEKS) e.push('daftar satuan terlalu besar');
    if (!o.alur || typeof o.alur !== 'object' || Array.isArray(o.alur)) e.push('alur harus berupa objek');
    else {
      for (const [k, v] of Object.entries(o.alur)) {
        if (!KEY_RE.test(k)) { e.push('kunci diagram tidak valid: ' + k); break; }
        if (!v || !Array.isArray(v.n) || !Array.isArray(v.e)) { e.push('diagram ' + k + ' tidak lengkap (n dan e harus daftar)'); break; }
      }
    }
    const rows = o.kapasitas && o.kapasitas.rows;
    if (!Array.isArray(rows)) e.push('kapasitas.rows harus berupa daftar');
    else {
      if (rows.length > MAX_ROWS) e.push('jumlah baris kapasitas melebihi batas');
      const bad = rows.find(r => !r || typeof r.kode !== 'string' || !r.kode || !Number.isInteger(r.tt) || r.tt < 0 || !DATE_RE.test(r.berlaku || ''));
      if (bad) e.push('baris kapasitas tidak valid: ' + (bad && bad.kode ? bad.kode : '(kosong)'));
    }
    return { ok: e.length === 0, errors: e };
  }

  return {
    CODE_RE, SPAN_WARN, DEFAULT_OUTLINE, EXAMPLE_FLOW,
    hid, parseOutline, eachUnit, eachNode, directUnits, findByPath,
    analyze, importRows, toCsv, flowKeyFor,
    DATE_RE, parseRuangan, kapasitasAsOf, cekTotal, kapasitasCsv, ringkasanCsv,
    BACKUP_VERSI, buatCadangan, validasiCadangan
  };
});
