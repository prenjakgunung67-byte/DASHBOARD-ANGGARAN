# Catatan Perubahan

Format: versi, tanggal, lalu perubahan dikelompokkan menurut jenisnya.
Semua perubahan dari v1 (usulan dasar di `diagram-organisasi.zip`) tercatat di bawah ini.

## v3.1.4 (20 November 2026)

### Diperbaiki
- **Logo tidak tampil** saat halaman dibuka dari hasil ekstrak zip di Windows. Logo sekarang ditanam langsung di `index.html` sebagai data, sehingga tidak bergantung pada jalur folder `assets/`. Ikon tab juga memakai data yang sama.

### Diubah
- **Halaman masuk:** logo di atas, judul dan nama rumah sakit di bawahnya, semuanya rata tengah.
- Folder `assets/` tidak lagi wajib untuk tampilan. Berkas `assets/rsf.png` tetap disimpan sebagai sumber.

## v3.1.3 (20 November 2026)

### Ditambahkan
- **Logo Kemenkes RS Fatmawati** di halaman masuk, di header, dan sebagai ikon tab browser. Berkas: `assets/rsf.png`. Logo ditampilkan di dalam wadah putih agar terbaca di latar teal.

### Diubah
- `index.html` memuat logo dari `assets/rsf.png`. Folder `assets/` harus ikut diunggah.

## v3.1.1 (20 November 2026)

### Ditambahkan
- **`migrasi/001-dasar-v1.sql`.** Skema dasar v1 (`struktur`, `alur`, RLS, kebijakan admin) sebagai migrasi pertama. Idempoten. Sebelumnya urutan migrasi dimulai dari 002.

### Diubah
- Dokumentasi urutan migrasi (README dan MIGRASI.md) menyebut urutan lengkap 001, 002, 003.

### Tidak berubah
- Nama dan isi 002 dan 003. Langkah yang sudah dijalankan tetap berlaku.

## v3.1.0 (19 November 2026)

### Ditambahkan
- **Cadangan lengkap (JSON).** Tombol "Unduh cadangan (JSON)" di tab Analisis menyimpan daftar satuan, seluruh diagram alur, data kapasitas, dan riwayat (hingga 1.000 entri terakhir) dalam satu berkas.
- **Pemulihan dari cadangan.** Berkas diperiksa dulu oleh `validasiCadangan`. Berkas yang bukan JSON, berasal dari aplikasi lain, atau memiliki struktur salah ditolak tanpa mengubah data. Sebelum pemulihan, keadaan sekarang disimpan di browser sebagai `pra_pulih`.
- **Pembatalan impor kapasitas terakhir.** Tombol "Batalkan impor terakhir" menukar data kapasitas dengan versi sebelum impor. Tekan lagi untuk kembali. Pembatalan hanya satu tingkat dan disimpan di browser.
- **Content Security Policy.** Halaman memakai CSP yang membatasi skrip hanya ke berkas sendiri dan CDN supabase-js. Pengujian di Chromium memastikan skrip inline yang disuntikkan diblokir.
- **`app.js`.** Seluruh skrip aplikasi dipindah dari `index.html`. Ini prasyarat CSP.
- **Panduan uji RLS** (`TESTING_RLS.md`) untuk dijalankan sendiri dengan akun non-admin di proyek Supabase Anda.
- **Uji.** 2 uji unit baru (cadangan dan validasi) dan 5 uji antarmuka baru (unduh cadangan, pemulihan, berkas rusak, cadangan dari aplikasi lain, pembatalan kapasitas).

### Diubah
- Empat berkas aplikasi sekarang: `index.html`, `core.js`, `app.js`, `config.js`. Ketiganya harus diunggah bersama.
- `core.js` dan `app.js` dimuat dengan parameter `?v=3.1.0` agar browser tidak memakai salinan lama.

### Tidak berubah
- Skema basis data. Tidak ada migrasi baru di v3.1.
- Perilaku pengguna lain di tab Struktur, Alur, Analisis, dan Kapasitas.

### Diketahui
- Pembatalan impor kapasitas hanya tersimpan di browser yang melakukan impor, bukan di cloud.
- Pemulihan cadangan tidak mengembalikan riwayat lama. Riwayat ditulis ulang sebagai satu entri "Pemulihan cadangan".
- Pengujian RLS dengan akun non-admin belum dilakukan oleh pengembang. Lakukan sesuai `TESTING_RLS.md`.

## v3.0.0 (19 November 2026)

### Ditambahkan
- **Tab Kapasitas.** Data ruangan dan tempat tidur per periode berlaku: gedung, kode dan nama ruangan, kode instalasi, kelas, jumlah TT operasional, tanggal berlaku (YYYY-MM-DD), dan nomor SK.
- **Impor dari Excel** dengan pemeriksaan galat. Galat (TT bukan bilangan, tanggal salah, kode ruangan atau tanggal berlaku ganda, kolom kosong) menolak seluruh impor. Peringatan (kode instalasi belum ada di daftar organisasi) tidak menghentikan impor.
- **Total per tanggal.** Pilih tanggal, dan aplikasi memakai versi terbaru tiap ruangan yang sudah berlaku pada tanggal itu. Versi yang berlaku sesudah tanggal itu diabaikan.
- **Pencocokan dengan SK.** Isi angka SK (default 851). Selisih ditampilkan dan statusnya "Sesuai" atau "Belum sesuai".
- **Rincian per instalasi** dengan tanda apakah kode instalasi sudah ada di daftar organisasi.
- **Ekspor CSV** dua jenis: rincian ruangan yang aktif pada tanggal terpilih, dan ringkasan TT per instalasi dengan baris TOTAL. Keduanya memakai pemisah titik koma dan BOM untuk Excel.
- **Penyimpanan cloud** di tabel `kapasitas` (satu baris, berisi seluruh data). Setiap impor tercatat di riwayat.
- **Migrasi 003** (`migrasi/003-kapasitas.sql`) dan skema baru di `schema.sql`.
- **Uji.** 10 uji unit baru untuk modul kapasitas dan 7 uji antarmuka baru. Total 40 uji unit dan 36 uji antarmuka.

### Diubah
- Menu navigasi bertambah satu tab, yaitu Kapasitas.
- Uji regresi terhadap v1 kini membaca salinan v1 di `tests/fixtures/v1-index.html`, sehingga bisa dijalankan dari dalam zip tanpa folder lain.
- `package.json` dibuat dengan skrip `npm test`.

### Tidak termasuk di v3 (sengaja)
- Perhitungan BOR dan ABK. Keduanya tetap di spreadsheet. Aplikasi hanya menyediakan data induk dan ekspor.
- Hari perawatan, kunjungan, dan tindakan. Data ini belum ada di aplikasi.
- Formasi dan jumlah pegawai per satuan.

### Diketahui
- Data ruangan belum diisi dengan data SK sungguhan. Pengujian memakai data contoh yang totalnya dibuat 851 hanya untuk menguji pencocokan.
- Kode instalasi di daftar organisasi belum diberi kode `{KODE}`. Akibatnya semua instalasi ditandai "Belum ada kode" sampai kode diisi.
- Impor memakai satu baris per ruangan per periode. Jika jumlah TT berubah tanpa SK baru, sebaiknya tetap dicatat dengan nomor SK yang sesuai.

## v2.0.0 (19 November 2026)

### Ditambahkan
- **Tab Analisis.** Kartu ringkasan (satuan kerja, tingkat organisasi, rentang kendali rata-rata, pejabat belum diisi, satuan tanpa diagram alur, satuan tanpa kode). Temuan dikelompokkan per jenis dan bisa diklik untuk langsung membuka satuannya.
- **Kode tetap satuan** dengan penulisan `{KODE}` di akhir nama, misalnya `Instalasi Farmasi {IFA}`. Diagram alur kini terikat ke kode, sehingga mengganti nama satuan tidak lagi memutus diagram.
- **Rincian satuan.** Klik satuan di bagan untuk melihat jalur induk, pejabat, jumlah bawahan langsung, dan status diagram alur. Tersedia tombol "Tampilkan di daftar" (menyorot baris di editor) dan "Buka diagram alur".
- **Klik dua kali** pada satuan langsung membuka diagram alurnya.
- **Ekspor CSV** untuk Excel (pemisah titik koma, dengan BOM agar huruf Indonesia terbaca benar). Kolom: kode, satuan kerja, induk, pejabat, kelompok, tingkat, bawahan langsung.
- **Riwayat perubahan.** Setiap penyimpanan ke cloud dicatat ke tabel `riwayat`: waktu, jenis perubahan, ringkasan, dan pengguna. Riwayat ditampilkan di tab Analisis.
- **Deteksi lingkaran induk saat impor.** Impor yang menyebabkan satuan saling menjadi induk ditolak dengan pesan yang menyebut nama satuannya. Di v1 satuan seperti itu diam-diam hilang.
- **Konfirmasi sebelum impor** karena daftar lama akan diganti.
- **Konfirmasi sebelum mengisi contoh** pada diagram yang sudah berisi.
- **Cetak** (tampilan cetak yang menyembunyikan panel).
- **Peringatan saat meninggalkan halaman** bila masih ada perubahan yang belum tersimpan ke cloud.
- **Notifikasi (toast)** untuk hasil impor, ekspor, dan galat.
- **Pintasan keyboard.** Tombol `/` memfokuskan pencarian; `Delete` menghapus pilihan di tab Alur.
- **Lencana peringatan** kecil di satuan yang pejabatnya belum diisi.
- **Uji otomatis.** 30 uji unit (`tests/test.js`) dan 29 uji antarmuka (`tests/ui-test.js`), termasuk uji regresi terhadap kode v1 yang diambil langsung dari berkas asli.
- **Skema basis data** untuk instalasi baru (`schema.sql`) dan **migrasi** untuk instalasi yang sudah berjalan (`migrasi/002-riwayat.sql`).

### Diubah
- **Logika dipisah ke `core.js`** (tanpa DOM) agar bisa diuji. `index.html` tetap berupa halaman statis yang bisa diunggah ke hosting biasa.
- **Tampilan diperbarui:** tema teal dengan gradien, kartu dengan bayangan lembut, huruf Inter, tipografi angka yang rata, dan dukungan `prefers-reduced-motion`.
- **Definisi "tingkat organisasi" diperbaiki.** Di v1 kelompok (`# Tim Kerja`, `# Instalasi`) ikut dihitung sebagai tingkat. Di v2 kelompok hanya menjadi kolom tampilan dan tidak menambah tingkat organisasi. Akibatnya angka tingkat pada data default berubah dari 4 menjadi 3 (lihat MIGRASI.md, M-06).
- **Angka "satuan kerja"** tetap tidak menghitung direktorat, sama seperti v1 (55 pada data default).
- **Tab Alur** kini memakai kunci kode bila tersedia, dengan cadangan kunci lama (lihat MIGRASI.md).
- **Teks panduan** pada daftar dan README diperbaiki (jumlah tempat yang harus diganti di SQL).
- **Bagan bergulir di dalam kanvasnya** dengan tinggi maksimum. Bilah alat dan panel rincian tetap terlihat saat bagan besar dibuka.
- **Saat pertama dibuka**, layar diarahkan ke akar organisasi, bukan ke tengah bagan.
- **Nama satuan di bagan dipangkas** pada 25 karakter. Nama lengkap tampil di tooltip dan di panel rincian.
- **Kotak pencarian** diberi placeholder singkat ("Cari satuan"). Pencarian tetap mencakup pejabat dan kode.

### Diperbaiki
- **Mode demo:** tombol "Keluar" yang tidak berfungsi kini disembunyikan.
- **Impor data kosong** kini menampilkan peringatan, bukan diam saja.
- **Impor dengan lingkaran induk** kini menolak dan menyebut satuan yang bermasalah (sebelumnya satuan dibuang tanpa pemberitahuan).
- **Gagal simpan** kini menampilkan pesan galat yang jelas dan tidak hanya teks status.
- **Kelas CSS yang tidak terpakai** (`.ro`, duplikasi aturan `.bar`) dihapus.
- **Galat impor tidak menghentikan halaman.** Pesan galat ditampilkan lewat notifikasi.

### Tidak berubah
- Format teks daftar (indentasi dua spasi, `# ` untuk kelompok, `| Pejabat`). Daftar lama tetap terbaca.
- Mekanisme masuk satu admin dengan Supabase Auth dan aturan RLS berbasis email.
- Ekspor SVG.
- Hosting statis (tanpa PHP atau Node.js di server).

### Diketahui belum tuntas
- Akun editor atau pembaca terpisah belum ada (masih satu admin).
- Persetujuan berjenjang (usulan, verifikasi, terbit) belum ada.
- Versi struktur per tanggal SK belum ada; yang tersedia hanya riwayat perubahan.
- Belum ada integrasi dengan SIASN, MyASN, SISDMK, atau SIMRS.
- Belum diuji pada Safari iOS, dan drag diagram alur di layar sentuh belum diuji langsung.
- Pengujian belum mencakup proyek Supabase sungguhan (pengujian memakai Supabase tiruan).
