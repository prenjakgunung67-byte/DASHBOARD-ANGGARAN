# Uji RLS dengan Akun Non-Admin

Tujuan: memastikan akun yang bukan admin tidak bisa membaca maupun menulis data. Ini harus dilakukan sekali sebelum data nyata dimasukkan. Pengujian otomatis tidak bisa menggantikannya, karena RLS hanya bisa diuji terhadap proyek Supabase sungguhan.

Waktu: sekitar 10 menit. Lakukan di proyek Supabase yang sudah dipasang, bukan di proyek lain.

## Langkah 1. Buat akun uji

1. Supabase, Authentication, Users, Add user.
2. Isi email yang **berbeda** dengan email admin, misalnya `uji-rls@contoh.id`, dengan kata sandi acak.
3. Centang *Auto Confirm User*, lalu Create user.

## Langkah 2. Buka aplikasi dan siapkan console

1. Buka alamat situs (Vercel atau Hostinger).
2. Tekan F12, pilih tab Console.
3. Pastikan halaman sudah memuat `supabase` (ketik `supabase` dan tekan Enter; hasilnya harus berupa objek, bukan galat).

## Langkah 3. Uji baca sebagai akun non-admin

Salin dan tempel di console. Ganti `URL` dan `ANON` dengan nilai dari `config.js`, dan ganti email serta kata sandi uji.

```js
const sbUji = supabase.createClient('URL', 'ANON');
await sbUji.auth.signInWithPassword({ email: 'uji-rls@contoh.id', password: 'KATA-SANDI-UJI' });
for (const t of ['struktur', 'alur', 'riwayat', 'kapasitas']) {
  const r = await sbUji.from(t).select('*');
  console.log(t, 'data:', r.data && r.data.length, 'galat:', r.error && r.error.message);
}
```

**Hasil yang benar:** setiap tabel mengembalikan `data: 0` (atau galat), dan tidak ada baris dari admin yang terlihat.

## Langkah 4. Uji tulis sebagai akun non-admin

```js
const w1 = await sbUji.from('struktur').upsert({ id: 1, teks: 'UJI RLS', diubah: new Date().toISOString() });
const w2 = await sbUji.from('kapasitas').upsert({ id: 1, isi: { rows: [] }, diubah: new Date().toISOString() });
const w3 = await sbUji.from('riwayat').insert({ jenis: 'uji', ringkas: 'uji', pengguna: 'uji' });
console.log('struktur:', w1.error && w1.error.message, '| kapasitas:', w2.error && w2.error.message, '| riwayat:', w3.error && w3.error.message);
```

**Hasil yang benar:** ketiganya menampilkan pesan galat (biasanya "new row violates row-level security policy" atau sejenisnya). Jika ada yang berhasil, **berhenti dan jangan memasukkan data nyata**. Periksa kebijakan di `schema.sql` dan pastikan email admin sudah benar.

## Langkah 5. Uji akses tanpa login

```js
const sbAnon = supabase.createClient('URL', 'ANON');
const r = await sbAnon.from('struktur').select('*');
console.log('anon:', r.data && r.data.length, r.error && r.error.message);
```

**Hasil yang benar:** `data: 0` atau galat.

## Langkah 6. Pembersihan

1. Keluar dari sesi uji: `await sbUji.auth.signOut()`.
2. Hapus akun uji di Authentication, Users.
3. Catat tanggal dan hasil uji di dokumen internal Anda.

## Jika ada yang gagal

Jangan lanjut ke pemasangan data nyata. Periksa dulu:
- Nilai `GANTI-EMAIL-ADMIN` di tabel yang gagal sudah diganti dengan email admin yang benar.
- RLS sudah aktif di tabel tersebut (`alter table ... enable row level security`).
- Tidak ada kebijakan tambahan yang dibuat secara manual di dashboard dan membuka akses.
