# Analisis Usulan, Perbandingan Aplikasi, dan Rekomendasi Pekerjaan

Versi 2.0 (19 November 2026). Disusun dari: berkas usulan dasar (`diagram-organisasi.zip`), hasil uji terhadap data default, dan pencarian sumber terbuka tentang produk sejenis dan regulasi terkait.

Catatan metode: perbandingan produk diambil dari ulasan dan halaman pembanding yang tersedia di web pada saat penulisan. Fitur dan harga belum saya uji langsung di setiap produk. Angka harga dari sumber pihak ketiga tidak saya pakai sebagai dasar keputusan.

---

## A. Analisis usulan dasar (v1)

### A.1. Yang sudah baik
- **Sederhana dan murah.** Hanya HTML, JavaScript, dan Supabase paket Free. Tidak perlu server.
- **Format teks daftar mudah dipelajari.** Pengguna yang bisa mengetik indentasi bisa langsung memakai aplikasi.
- **Keamanan baris dasar sudah benar.** RLS membatasi baca dan tulis ke satu email admin, dan dokumentasi menekankan agar langkah RLS tidak dilewati.
- **Diagram alur terintegrasi dengan struktur.** Kebanyakan aplikasi bagan organisasi tidak punya alur kerja (SOP) visual per satuan. Ini nilai khas yang sebaiknya dipertahankan.
- **Ekspor SVG dan tampilan tanpa dependensi berat.**

### A.2. Kelemahan yang ditemukan dan sudah diperbaiki di v2
| Temuan | Dampak | Perbaikan |
|---|---|---|
| Diagram terikat ke nama satuan. Mengganti nama membuat diagram "hilang". | Kehilangan tampilan kerja, sering tidak disadari | Kode tetap `{KODE}`, kunci lama tetap dibaca (M-04) |
| Impor dengan induk yang saling merujuk membuang satuan tanpa pesan | Data tidak lengkap tanpa diketahui | Deteksi lingkaran dan pesan galat (uji) |
| Tidak ada riwayat perubahan | Tidak bisa diaudit | Tabel `riwayat` dan tampilannya |
| Angka "tingkat" menghitung kelompok | Angka menyesatkan (4 padahal 3 tingkat sebenarnya) | Tingkat dihitung dari satuan induk (M-06) |
| Tombol "Keluar" tidak berfungsi di mode demo | Membingungkan | Disembunyikan di mode demo |
| Dokumentasi menyebut "dua tempat" untuk email admin | Pemasangan bisa gagal | Dikoreksi; dianjurkan Find and Replace |
| Tidak ada analisis, tidak ada temuan | Tidak mendukung peran analis organisasi | Tab Analisis dan ekspor CSV |
| Semua logika dalam satu berkas tanpa uji | Sulit dipelihara dan diuji | `core.js` dengan 30 uji unit dan 29 uji antarmuka |

### A.3. Temuan dari data default (60 baris usulan)

Angka berikut dihitung oleh aplikasi v2 dari daftar default yang Anda lampirkan:

- **55 satuan kerja** ditambah **5 direktorat** (termasuk Direktorat Utama) dan **13 kelompok jenis**.
- **3 tingkat organisasi.** Tingkat 1: 1 satuan (Direktorat Utama). Tingkat 2: 12 satuan. Tingkat 3: 47 satuan.
- **Rentang kendali rata-rata 11,8** bawahan langsung, dengan **maksimum 31** pada **Direktorat Medik dan Keperawatan**. Direktorat ini memiliki 3 tim kerja, 11 instalasi, 5 unit, dan 12 departemen sebagai bawahan langsung.
- **Hanya 1 satuan** yang melewati ambang 12 bawahan, yaitu Direktorat Medik. Direktorat Utama berada tepat di 12 bawahan langsung (4 direktorat, 5 komite, 1 satuan pemeriksaan internal, dan 2 unit).
- **Pejabat belum diisi** pada semua 60 satuan. Ini wajar untuk usulan awal, tetapi harus dilengkapi sebelum bagan dipakai untuk pengambilan keputusan.
- **Belum ada kode dan belum ada diagram alur** pada satu pun satuan.

Implikasi analitis:
1. Sekitar 78% satuan (47 dari 60) berada di tingkat 3. Ini berarti sebagian besar penanggung jawab layanan berada satu lapis di bawah direktorat, tanpa lapisan koordinator. Apakah ini disengaja perlu ditelaah dengan pimpinan. Jangan diubah sebelum ada keputusan.
2. Direktorat Medik membawa 31 bawahan langsung. Dari sisi manajemen, ini sangat lebar dan sulit diawasi secara langsung. Pilihan yang bisa ditelaah: pengelompokan ke dalam bidang atau koordinator per rumpun layanan (misalnya rawat jalan, rawat inap, penunjang), atau pemisahan sebagian satuan ke direktorat lain. Keputusan ini berada di tangan pimpinan.
3. Kelompok "Instalasi" dan "Departemen" berada pada tingkat yang sama di bawah direktorat. Perlu dipastikan bahwa penamaan ini sesuai dengan dasar hukum OTK yang berlaku, terutama bila ada perbedaan antara departemen medik dan instalasi penunjang.

---

## B. Perbandingan aplikasi sejenis

### B.1. Kelas produk

Ada tiga kelas produk yang relevan:
1. **Alat penggambar diagram** (Visio, Lucidchart, draw.io): fleksibel untuk gambar, tetapi bagan tidak terhubung ke data kepegawaian dan harus digambar ulang setiap ada perubahan.
2. **Platform bagan organisasi dan direktori karyawan** (Pingboard, Organimi, ChartHop, OrgChart, Sift): bagan dibentuk dari data karyawan dan dapat disinkronkan dengan sistem HR.
3. **HRIS atau suite SDM** (BambooHR, Rippling, Personio, Factorial, Leapsome): bagan adalah salah satu fitur di dalam sistem SDM yang lebih besar.

Aplikasi v2 berada di kelas pertama yang diberi kemampuan analisis dan alur kerja. Ia tidak bersaing dengan kelas kedua dan ketiga dalam hal integrasi data karyawan.

### B.2. Perbandingan internasional

| Produk | Kelas | Kekuatan yang dicatat sumber | Keterbatasan yang dicatat sumber | Relevansi untuk RS |
|---|---|---|---|---|
| **Pingboard** (Workleap) | Direktori dan bagan | Antarmuka sederhana; disinkronkan dengan HRIS; fokus pada direktori karyawan | Dikenal lebih kuat di sisi keterlibatan karyawan | Sedang. Lebih cocok untuk perusahaan dengan banyak pegawai non-ASN |
| **Organimi** | Pembuat bagan | Drag and drop; direkomendasikan sebagai pilihan umum untuk HR dan operasi | Bagan tidak otomatis terhubung ke sistem kepegawaian | Sedang. Mudah, tetapi tidak menyediakan alur kerja |
| **ChartHop** | Bagan terhubung HR | Bagan memperbarui sendiri dari data HR; analitik SDM | Harga per pengguna; tanpa ekspor PDF atau PNG pada sebagian paket (menurut pembanding) | Sedang. Kuat untuk analitik, tidak untuk sistem ASN |
| **OrgChart** (theorgchart.com) | Bagan dan perencanaan tenaga kerja | Cocok untuk struktur matriks dan perencanaan tenaga kerja | Biasanya untuk organisasi besar dengan harga penawaran | Relevan untuk fase 2 (formasi) |
| **Ingentis org.manager, Sift, OrgPlus RealTime** | Enterprise, matriks | Mendukung struktur kompleks dan skenario perencanaan | Biaya dan implementasi berat | Berlebihan untuk kebutuhan saat ini |
| **Lucidchart, Microsoft Visio** | Diagram umum | Diagram alur dan bagan; Visio disebut tersedia dalam paket Microsoft 365 pada salah satu ulasan | Tidak terhubung data; perubahan harus digambar ulang | Dekat dengan kebutuhan diagram alur, tetapi tidak dengan data |
| **draw.io** | Diagram umum, gratis | Gratis tanpa pendaftaran, tanpa batas bentuk | Tidak terhubung data; tidak ada analisis | Alternatif untuk diagram alur saja |
| **Oak Engage** | Bagan dan komunikasi karyawan | Bagan digabung dengan direktori dan komunikasi | Fokus pada keterlibatan, bukan tata kelola | Rendah |
| **Leapsome, Personio, BambooHR, Rippling, Factorial** | HRIS dan suite SDM | Pada beberapa produk bagan dasar tersedia di dalam HRIS (BambooHR dan Rippling menurut satu ulasan); bagan terhubung data | Perlu berlangganan HRIS penuh | Rendah untuk ASN, karena data pegawai ASN dikelola sistem pemerintah |

Yang bisa dipelajari dari produk internasional:
- **Sinkronisasi dengan sumber data.** Produk terbaik membuat bagan memperbarui sendiri dari data HR. Ini tujuan jangka panjang kita (fase 2 dan 3).
- **Tampilan rincian satuan saat diklik.** Sudah diadopsi di v2.
- **Ekspor dan berbagi tautan.** Belum ada tautan baca-saja yang aman. Ini bisa dipertimbangkan setelah fase 1.
- **Pesan langsung dari kartu pegawai.** Tidak relevan untuk tahap ini.

### B.3. Perbandingan nasional (Indonesia)

Produk nasional yang relevan bukan aplikasi bagan komersial, melainkan sistem resmi pemerintah yang menjadi sumber data kepegawaian dan operasional rumah sakit.

| Sistem | Pengelola | Fungsi | Hubungan dengan aplikasi ini |
|---|---|---|---|
| **SIASN** | BKN | Sistem informasi manajemen ASN secara terintegrasi. Memuat perencanaan kebutuhan: pengajuan struktur organisasi baru, formasi, dan penetapan kebutuhan pegawai | Sumber data resmi. Aplikasi ini harus mengikuti kode dan nama unit yang ada di sini |
| **MyASN dan ASN Digital** | BKN | Layanan mandiri ASN. ASN Digital digabung dari MyASN, SIASN, dan SSCASN. Pengaktifan wajib bagi PNS dan PPPK mulai 2026 menurut pemberitaan | Pegawai bisa memeriksa data unit mereka di sini |
| **e-Kinerja BKN** | BKN | Pengelolaan kinerja pegawai, terintegrasi dengan SIASN, memakai struktur data baku BKN | Bagan dapat dipakai sebagai acuan hubungan penilai dan yang dinilai |
| **SIMPEG daerah** (contoh: Kabupaten Mojokerto) | Pemerintah daerah | Data ASN terpadu per perangkat daerah, pemantauan kenaikan pangkat dan pensiun | Contoh praktik lokal: data kepegawaian terhubung per unit |
| **SISDMK** | Kemenkes | Sistem informasi SDM kesehatan. Per 21 Oktober 2026 tercatat 93 persen wilayah masih membutuhkan dokter spesialis, dengan kekurangan 55.192 dokter | Acuan kebutuhan tenaga kesehatan nasional; relevan untuk fase 2 |
| **SIMRS, SIRS, SISMADAK** | Kemenkes dan rumah sakit | Sistem operasional rumah sakit dan pelaporan mutu | Kode satuan bisa dipetakan ke unit operasional di sini |
| **Holding RS Kemenkes** (rs.kemkes.go.id) | Kemenkes | Situs yang menghimpun informasi seluruh rumah sakit vertikal, diluncurkan Februari 2026 | Konteks: rumah sakit vertikal sedang diarahkan ke data terpusat |
| **Integrasi SIMRS terpusat dan SATUSEHAT** pada 42 RS vertikal | Kemenkes | Percepatan integrasi per Agustus 2026 | Menunjukkan arah: data rumah sakit makin terpusat |

Dasar regulasi yang perlu diverifikasi:
- **Permenkes 26 Tahun 2022.** Mengatur organisasi dan tata kerja rumah sakit di lingkungan Kemenkes. Rumah sakit vertikal didefinisikan sebagai UPT.
- **Permenkes 6 Tahun 2026.** Ditetapkan 4 Juni 2026 dan berlaku sejak 12 Juni 2026. Menurut ringkasan dari beberapa sumber, peraturan ini mencabut dan menggantikan 21 peraturan lama, termasuk aturan sistem informasi rumah sakit (1171/2011 dan 82/2013). Dampaknya terhadap OTK perlu dicek langsung ke naskah resminya.
- **Permenkes 21 Tahun 2024** tentang organisasi Kemenkes. Sudah dirujuk dalam laporan kinerja unit Kemenkes sebagai dasar perubahan struktur.

### B.4. Temuan penting dari sistem nasional

Ada satu temuan yang langsung memengaruhi desain aplikasi. Dalam salah satu dokumen perbaikan anomali data kepegawaian pemerintah daerah tercatat bahwa ASN bisa berada pada unit organisasi yang sudah nonaktif, dan bahwa perbaikan data unor dilakukan lewat riwayat jabatan di SIASN. Artinya:

- Struktur internal yang dikelola di aplikasi ini **harus memiliki kode yang bisa dicocokkan** dengan kode unit organisasi di SIASN. Jika tidak, data pegawai dan bagan akan berbeda dan sulit didamaikan.
- Perubahan struktur di aplikasi harus diikuti perubahan di SIASN, dan sebaliknya.

Inilah alasan rekomendasi T-15 (pemetaan kode) dan pentingnya kolom kode diisi sejak awal, bukan nanti.

### B.5. Posisi aplikasi kita

| Aspek | Aplikasi v2 | Produk komersial | Kesimpulan |
|---|---|---|---|
| Biaya lisensi | Hampir nol (Supabase Free dan hosting) | Berlangganan per pengguna atau per karyawan | Keunggulan besar untuk organisasi publik |
| Kepemilikan data | Di akun Supabase milik organisasi | Di penyedia | Keunggulan untuk kebijakan data, perlu diatur dengan benar |
| Alur kerja (SOP) visual per satuan | Ada | Umumnya tidak ada | Pembeda utama |
| Analisis struktur | Dasar | Lanjutan (analitik SDM) | Perlu ditingkatkan di fase 2 |
| Sinkronisasi HR otomatis | Belum | Ada | Gap terbesar; bergantung pada akses data resmi |
| Persetujuan berjenjang dan peran | Belum | Umumnya ada | Gap yang harus ditutup di fase 1 |
| Aplikasi seluler | Tidak ada, tetapi tampilan responsif | Umumnya ada | Cukup untuk tahap ini |
| Dukungan dan SLA | Mandiri | Ada | Risiko operasional; perlu ada pemilik teknis |
| Bahasa dan konteks | Bahasa Indonesia, istilah rumah sakit | Umumnya bahasa Inggris | Keunggulan |

Kesimpulan: untuk kebutuhan RSUP Fatmawati, pendekatan membangun sendiri yang diperkuat tata kelola lebih sesuai daripada berlangganan produk komersial. Gap terbesar adalah integrasi data resmi dan persetujuan berjenjang. Keduanya bisa dicapai bertahap.

---

## C. Rekomendasi pekerjaan

Urutan di bawah ini memperhitungkan dampak, risiko, dan prasyarat. Perkiraan waktu adalah untuk satu programmer dan satu analis.

### C.1. Segera (1 sampai 2 minggu)

1. **Pasang v2 dengan migrasi M-01 dan M-02.** Jalankan `migrasi/002-riwayat.sql`, unggah tiga berkas, lalu cek bahwa tab Analisis dan riwayat berfungsi. *Penanggung jawab: programmer.*
2. **Uji RLS dengan akun non-admin.** Pastikan baca dan tulis ditolak. Ini pemeriksaan keamanan paling penting sebelum data nyata dimasukkan. (T-03) *Programmer.*
3. **Tetapkan aturan kode satuan.** Putuskan kode dibuat dari kode unor SIASN atau dari singkatan internal. Kode harus unik dan stabil. Tulis aturannya dalam satu halaman. *Tim Kerja Organisasi dan SDM bersama analis.*
4. **Isi kode `{KODE}` untuk seluruh satuan.** Lakukan setelah aturan kode disepakati. Setelah ini, kartu "Belum ber-kode" di tab Analisis menjadi nol. *Analis.*
5. **Lengkapi pejabat per satuan.** Dimulai dari direktorat dan tingkat 2, lalu tingkat 3. Target: kartu "Pejabat belum diisi" menjadi nol. *Tim Kerja Organisasi dan SDM.*
6. **Ambil cadangan awal.** Unduh CSV dan SVG, simpan di dua tempat berbeda. (T-04 untuk cadangan lengkap, sebagai langkah sementara cukup CSV dan SVG.) *Analis.*

### C.2. Bulan ini (3 sampai 5 minggu)

7. **Telaah temuan struktural dengan pimpinan.** Bawa tiga temuan dari bagian A.3 (rentang kendali 31 di Direktorat Medik, dominasi tingkat 3, dan posisi Direktorat Utama di ambang 12) sebagai bahan diskusi. Ini keputusan pimpinan, bukan keputusan aplikasi. *Analis dan Direksi.*
8. **Verifikasi dasar hukum OTK.** Cek Permenkes 26/2022 dan 6/2026 ke naskah resmi. Tentukan apakah ada perubahan struktur yang harus dilakukan. Catat hasilnya di riwayat atau dokumen tersendiri. *Bagian hukum dan Tim Kerja Organisasi dan SDM.*
9. **Buat diagram alur untuk layanan prioritas.** Mulai dari IGD, rawat jalan, rawat inap, farmasi, laboratorium, radiologi, dan rekam medis serta penjaminan pasien. Setiap diagram menunjukkan kotak keputusan dan siapa yang bertanggung jawab. *Pejabat satuan dengan analis.*
10. **Hubungkan kode satuan ke analisis beban kerja (ABK) berbasis BOR.** Unit yang sudah Anda susun untuk ABK (IGD, rawat jalan, rawat inap, IGH, UKVI, IBS, hemodialisa, penunjang, dan lainnya) sebaiknya memakai kode yang sama dengan aplikasi ini. Dengan begitu, data struktur dan data beban kerja bisa digabung tanpa pencocokan manual. *Analis perencanaan dan programmer.*
11. **Jalankan uji mingguan.** Buka tab Analisis setiap minggu dan catat perubahan temuannya. *Analis.*

### C.3. Kuartal berikutnya (fase 1 sampai 2)

12. **Fase 1: tata kelola.** Peran editor dan pembaca (T-05), alur status perubahan (T-06), versi per SK (T-07), dan periode jabatan (T-08). Kerjakan dalam urutan ini karena versi per SK bergantung pada status perubahan.
13. **Fase 1: keamanan lanjutan.** Pisahkan skrip inline dan pasang Content Security Policy (T-01), lalu tambahkan versi pada tautan skrip (T-02).
14. **Fase 2: formasi dan ABK.** Kolom formasi per satuan (T-12), lalu dashboard rasio (T-14). Impor data pegawai dari berkas resmi (T-13) dikerjakan setelah format berkas disepakati.
15. **Fase 2: aksesibilitas dan perangkat sentuh.** Navigasi keyboard pada bagan (T-10) dan uji pada perangkat sentuh serta Safari (T-11).

### C.4. Fase 3 (bergantung pada akses resmi)

16. Pemetaan kode ke sistem kepegawaian nasional (T-15), dan integrasi dengan SIMRS atau SATUSEHAT bila tersedia antarmuka resmi. Jangan memulai sebelum ada izin dan dokumen teknis dari pemilik sistem.

---

## D. Keputusan yang perlu diambil pengguna

Berikut lima pertanyaan yang jawabannya akan mengubah arah pengembangan:

1. **Apakah aplikasi ini menjadi sumber resmi struktur, atau cermin dari SK dan SIASN?** Jika sumber resmi, diperlukan persetujuan dan versi per SK sejak awal. Jika cermin, cukup riwayat dan sinkronisasi berkala.
2. **Siapa saja yang perlu mengedit, dan siapa yang cukup membaca?** Ini menentukan prioritas T-05.
3. **Apakah nama pejabat boleh tampil ke seluruh pegawai?** Jika tidak, bagian pembaca perlu dibatasi lebih ketat, atau kolom pejabat dipisahkan.
4. **Apakah organisasi bersedia membayar paket Supabase berbayar?** Ini menghilangkan risiko jeda dan menambah cadangan harian. Keputusan ini bisa diambil setelah tiga bulan pemakaian.
5. **Apakah ada standar penamaan dan kode resmi di lingkungan Kemenkes atau RSUP Fatmawati?** Jika ada, aturan kode mengikuti standar itu. Jika belum, tetapkan dalam tim.

---

## E. Sumber yang digunakan

Produk internasional (ulasan dan halaman pembanding, diakses saat penulisan):
- Oak, "Best org chart software" (oak.com).
- Organimi, "Best org chart software 2026" (organimi.com).
- Guideflow, "8 best org chart software for 2026" (guideflow.com).
- Anywherer, perbandingan 26 alat bagan organisasi dan sinkronisasi HR (anywherer.com).
- Hackceleration, "What is the best org chart software in 2026?" (hackceleration.com).
- Leapsome, "8 best org chart software tools for 2026" (leapsome.com).
- Creately, "The 10 Best Org Chart Software in 2026" (creately.com).
- Intervue, "best org chart software" (intervue.io).

Sistem nasional dan regulasi:
- Suara.com, "Fitur-fitur SIASN 2025: Update Terbaru untuk Manajemen Pegawai" (September 2025).
- Detik Finance, "Cara Aktivasi ASN Digital Lewat asndigital.bkn.go.id" (2 Januari 2026).
- InfoBankNews, "PNS dan PPPK Wajib Pakai ASN Digital" (2026).
- BKN, Surat Edaran tentang Aplikasi e-Kinerja BKN (jdih.bkn.go.id, 2023).
- BKD Jawa Timur, "Inovasi Pelayanan Kepegawaian" (berisi contoh SIMPEG Kabupaten Mojokerto).
- Pemerintah daerah (Hulu Sungai Selatan), "Cara perbaikan anomali" (data unor dan SIASN, September 2025).
- Antara, "Kemenkes beri 4.592 beasiswa di 2024-2026 percepat pemenuhan spesialis" (2026).
- Keslan Kemenkes, "42 RS Vertikal Kemenkes percepat integrasi SIMRS terpusat dan SATUSEHAT" (24 Agustus 2026).
- Keslan Kemenkes, "Kementerian Kesehatan berikan penghargaan ke rumah sakit vertikal" (Februari 2026).
- Veritask, "Peraturan Menteri Kesehatan Nomor 6 Tahun 2026" (ringkasan).
- Peraturan BN 964/2022, Permenkes 26/2022 tentang organisasi dan tata kerja rumah sakit di lingkungan Kemenkes.
- Pasal.id, ringkasan Permenkes 26/2022.

Verifikasi yang belum dilakukan:
- Harga dan paket produk komersial belum diverifikasi langsung dari situs resmi.
- Naskah Permenkes 6/2026 belum dibaca langsung dari sumber resmi; hanya ringkasan.
- Belum dicek apakah Permenkes 26/2022 masih berlaku utuh setelah 6/2026.
