# Rancangan Teknis

Versi 2.0 (19 November 2026). Ditujukan untuk programmer yang akan melanjutkan atau memelihara aplikasi.

## 1. Gambaran arsitektur

    Browser (statis)                         Supabase (cloud)
    ┌──────────────────────────────┐         ┌──────────────────────────┐
    │ index.html                   │  HTTPS  │ Auth (email + sandi)     │
    │  ├─ UI, tab, SVG, event      │ ──────► │ Postgres                 │
    │  └─ memanggil core.js        │         │  ├─ struktur  (1 baris)  │
    │ core.js (logika murni)       │         │  ├─ alur      (per satuan│
    │  parse, analyze, import, CSV │         │  └─ riwayat   (log)      │
    │ config.js (URL dan anon key) │         │ RLS: hanya email admin   │
    └──────────────────────────────┘         └──────────────────────────┘
         hosting statis (Hostinger)

Prinsip: tidak ada server aplikasi. Seluruh logika berjalan di browser. Supabase hanya menyediakan autentikasi, basis data, dan keamanan baris (RLS).

## 2. Susunan berkas

| Berkas | Tanggung jawab | Ketergantungan |
|---|---|---|
| `core.js` | Penguraian daftar, pohon, analisis, impor, CSV, kode, hash | Tidak ada (tanpa DOM, tanpa jaringan) |
| `index.html` | Render SVG, event, state, sinkronisasi cloud, tab | `core.js`, `config.js`, supabase-js (CDN) |
| `config.js` | `window.APP_CONFIG` | Tidak ada |
| `schema.sql` | Skema instalasi baru | Tidak ada |
| `migrasi/*.sql` | Perubahan skema bertahap, idempoten | Tidak ada |
| `tests/test.js` | Uji unit `core.js` dan regresi v1 | Node.js |
| `tests/ui-test.js` | Uji perilaku halaman (jsdom) | jsdom |

`core.js` memakai pola UMD: di browser ia menjadi `window.OrgCore`, di Node ia menjadi `module.exports`. Ini memungkinkan logika yang sama diuji tanpa browser.

## 3. Format daftar (grammar)

    daftar    := baris*
    baris     := indent nama-atau-kelompok [ " | " pejabat ]
    indent    := (2 spasi)^d     ; d = kedalaman, dimulai dari 0
    kelompok  := "# " nama       ; tidak dihitung sebagai satuan
    nama      := teks [ " " kode ]
    kode      := "{" [A-Za-z0-9._-]{1,20} "}"   ; di akhir nama
    pejabat   := teks            ; boleh mengandung "|" (dipisah hanya di kemunculan pertama)

Aturan penguraian:
- Baris kosong diabaikan.
- Kedalaman ditentukan dari jumlah spasi di awal, dibagi dua (dibulatkan ke bawah).
- Baris dengan nama kosong diabaikan.
- Bila ada satu akar, itu adalah akar pohon. Bila banyak akar, dibuat akar virtual bernama "Organisasi".

## 4. Model data

### 4.1. Tabel `struktur`
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | int (PK, = 1) | Selalu satu baris; check `id = 1` |
| teks | text | Isi daftar satuan kerja |
| diubah | timestamptz | Waktu terakhir disimpan |

### 4.2. Tabel `alur`
| Kolom | Tipe | Keterangan |
|---|---|---|
| kunci | text (PK) | `c-KODE` untuk satuan berkode; `uXXXX` (hash path) untuk satuan lama |
| isi | jsonb | `{ n: [kotak], e: [garis] }` |
| diubah | timestamptz | Waktu terakhir disimpan |

Kotak: `{id, x, y, t, k}` dengan `k` ∈ {`start`, `proc`, `dec`}. Garis: `{a, b, l}`.

### 4.3. Tabel `riwayat`
| Kolom | Tipe | Keterangan |
|---|---|---|
| id | bigint identity (PK) | |
| waktu | timestamptz | default now() |
| jenis | text | Contoh: "Daftar satuan kerja", "Diagram alur" |
| ringkas | text | Ringkasan singkat perubahan |
| pengguna | text | Email pengguna yang menyimpan |

Indeks: `riwayat_waktu_idx (waktu desc)`.

## 5. Identitas satuan

Ini keputusan desain yang paling penting untuk stabilitas.

- Satuan berkode: `id = 'c-' + kode`. Stabil selama kode tidak diubah.
- Satuan tanpa kode: `id = hid(path)`, di mana `path` adalah jalur nama lengkap (`/Direktorat A/Instalasi B`) dan `hid` adalah hash v1 (`u` + basis-36 dari `h = h*31 + c`, dengan `>>> 0`).
- `legacy = hid(path)` selalu dihitung, bahkan untuk satuan berkode. Ini dipakai untuk membaca diagram v1.

Pembacaan diagram: `flowKeyFor(unit, keys)` mengembalikan `unit.id` bila ada di `keys`, kalau tidak `unit.legacy` bila ada, kalau tidak `unit.id` (kunci baru untuk penyimpanan pertama).

Batasan yang diketahui: bila nama satuan berkode tanpa kode diubah, `legacy` berubah dan diagram lama tidak terbaca lagi. Ini sama dengan perilaku v1 dan ditandai di tab Analisis sebagai "Belum ber-kode".

## 6. Algoritma utama

### 6.1. Penguraian (`parseOutline`)
Satu kali pindai baris dengan tumpukan (stack) berisi pasangan (node, kedalaman). Kompleksitas O(n). Setiap node menyimpan `line` (nomor baris 0-based) untuk fitur "Tampilkan di daftar".

### 6.2. Penelusuran (`eachUnit`)
Rekursif. Membawa tiga nilai:
- `depth`: kolom tampilan. Kelompok ikut menambah kolom (sesuai tampilan bagan).
- `tier`: tingkat organisasi. Hanya satuan yang menambah tingkat.
- `parent`: satuan induk langsung, dilewati kelompok.

### 6.3. Analisis (`analyze`)
- Nama ganda dan kode ganda: peta (Map) ke daftar node. Kompleksitas O(n).
- Rentang kendali: `directUnits(n)` menelusuri ke bawah melewati kelompok. Total O(n) karena setiap satuan dikunjungi sekali sebagai anak langsung dari induknya.
- Temuan diurutkan menurut tingkat keparahan: error, warn, info.

### 6.4. Impor (`importRows`)
1. Pisahkan baris berdasarkan tab atau titik koma. Lewati header bila kolom kedua berisi "induk" atau "parent".
2. Bangun Map nama ke node (baris pertama yang menang bila nama ganda).
3. Pasang setiap node ke induknya. Bila kolom Kelompok terisi dan induk ada, node dimasukkan ke kelompok di bawah induk.
4. Tandai node yang tercapai dari akar. Node yang tidak tercapai berarti ada lingkaran; lempar galat dengan daftar namanya.
5. Serialisasi ke teks daftar.

Uji `importRows` memastikan impor yang dihasilkan dapat diurai kembali.

### 6.5. Ekspor CSV (`toCsv`)
- Pemisah `;`, tanda kutip ganda untuk setiap sel, tanda `""` untuk kutip di dalam sel.
- Diawali BOM (`\ufeff`) agar Excel membaca UTF-8 dengan benar.
- Baris ditutup `\r\n`.

## 7. Sinkronisasi dan konsistensi

- **Debounce 700 ms** per kunci (`saveTimers[tk]`). Satu kunci hanya memiliki satu timer aktif.
- **Himpunan pending** (`pendingSave`). Kunci ditambahkan saat dijadwalkan dan dihapus setelah selesai (berhasil atau gagal). Dipakai untuk peringatan `beforeunload`.
- **Penulisan riwayat** dilakukan setelah penulisan data berhasil. Riwayat tidak diringkas; setiap penyimpanan dicatat.
- **Model last-write-wins.** Tidak ada penguncian optimistik. Karena satu admin, risiko konflik kecil. Fase 1 dengan beberapa editor perlu `diubah` sebagai syarat versi (compare-and-set).
- **Penyimpanan lokal** (`localStorage`) dipakai sebagai draf di mode demo dan sebagai cadangan untuk daftar (`org3`).

## 8. Keamanan

Yang sudah ada:
- RLS aktif pada semua tabel. Kebijakan hanya mengizinkan `auth.jwt() ->> 'email' = <email admin>`.
- Anon key boleh terlihat di browser; ini normal untuk Supabase, asalkan RLS aktif.
- Semua teks dari pengguna ditampilkan dengan `textContent` atau dengan `esc()` bila lewat `innerHTML`. Uji "nama dengan karakter HTML" memastikan struktur pohon tidak berubah.
- Tidak ada `eval` atau `new Function` di kode aplikasi.

Sudah diterapkan di v3.1:
- Skrip inline dipindah ke `app.js`. Content Security Policy dipasang di `index.html`:
  `default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src 'self' https://*.supabase.co; img-src 'self' data:; object-src 'none'; base-uri 'self'; form-action 'self'`
- Pengujian: skrip inline yang disuntikkan di Chromium diblokir dan tercatat sebagai pelanggaran.

Yang masih disarankan:
- Header keamanan dari hosting (lihat di bawah). Sebelumnya CSP yang disarankan adalah:
  `default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src https://*.supabase.co; img-src 'self' data:`
- Tambahkan header keamanan di hosting bila tersedia (X-Content-Type-Options, Referrer-Policy).
- Kebijakan kata sandi kuat dan autentikasi dua faktor untuk akun admin (fitur Supabase).
- Pengecekan RLS berkala: uji dengan akun non-admin bahwa baca dan tulis ditolak.

## 9. Performa

- Penggambaran ulang penuh (`drawOrg`) dilakukan pada setiap perubahan. Dengan sekitar 100 satuan ini cepat. Bila jumlah melebihi sekitar 500 satuan, pertimbangkan:
  - Gambar ulang hanya saat jeda ketik (debounce render terpisah dari debounce simpan).
  - Cache hasil `analyze` selama render yang sama.
- Layout dihitung dengan pass rekursif tunggal. Tidak ada pengukuran DOM kecuali `clientWidth` saat "Muat lebar".
- Bagan SVG tidak memakai filter pada setiap simpul; hanya simpul yang dipilih dan akar yang memakai bayangan.

## 10. Aksesibilitas dan antarmuka

- Tab memakai `role="tab"`, `aria-selected`, dan `aria-controls`. Panel memakai `role="tabpanel"`.
- Status sinkronisasi memakai `aria-live="polite"`.
- Fokus terlihat pada semua tombol dan input (`:focus-visible`).
- `prefers-reduced-motion` mematikan animasi.
- Belum diuji dengan pembaca layar. Bagan SVG memiliki `role="img"` dan `aria-label`, tetapi simpulnya belum memiliki navigasi keyboard. Ini perlu ditambahkan pada fase 1.
- Pintasan `/` dan `Delete` dihentikan saat fokus berada di input atau textarea.

## 11. Pengujian

| Lapisan | Berkas | Cakupan | Jalankan |
|---|---|---|---|
| Unit | `tests/test.js` | Penguraian, kode, kelompok, analisis, impor, CSV, kompatibilitas v1 | `node tests/test.js` |
| Antarmuka | `tests/ui-test.js` | Mode demo, migrasi v1, mode cloud (Supabase tiruan), alur, galat JavaScript | `node tests/ui-test.js` |

Uji antarmuka memakai jsdom dengan pemuat sumber daya khusus. Jaringan (CDN dan Google Fonts) dikosongkan. Supabase diganti tiruan (`fakeSupabase`) yang mengimplementasikan subset API yang dipakai aplikasi. Penangkap galat JavaScript memastikan exception di dalam halaman ikut menggagalkan uji.

Hal yang belum diuji otomatis:
- Supabase sungguhan (RLS, Auth, batas kuota).
- Interaksi sentuh pada diagram alur (pointer events di perangkat sentuh).
- Browser Safari dan Firefox.

Pengujian tampilan dilakukan manual dengan Chromium headless (tangkapan layar di folder `pratinjau/`).

Untuk menambah uji: letakkan logika baru di `core.js` dan tambahkan uji unit. Perilaku UI diuji di `ui-test.js` dengan `makePage()`.

## 12. Pemasangan dan operasi

- Pemasangan baru: lihat README.md.
- Pemutakhiran dari v1: lihat MIGRASI.md.
- Hosting: unggah `index.html`, `core.js`, dan `config.js` ke folder yang sama.
- Cache browser: karena berkas tidak diberi versi, pengguna yang sudah membuka aplikasi bisa memakai `index.html` lama beberapa saat. Tambahkan parameter versi pada tautan skrip (`core.js?v=2`) atau minta pengguna memuat ulang dengan Ctrl+F5.

## 13. Daftar kerja untuk programmer

Prioritas: P1 segera, P2 dalam fase 1, P3 dalam fase 2.

| No | Prioritas | Pekerjaan | Perkiraan | Keterangan |
|---|---|---|---|---|
| T-01 | P1 | Pindahkan skrip inline ke `app.js`; pasang CSP | 0,5 hari | Prasyarat keamanan |
| T-02 | P1 | Tambahkan parameter versi pada skrip (`?v=2`) | 0,1 hari | Mencegah cache lama |
| T-03 | P1 | Uji RLS sungguhan dengan akun non-admin | 0,5 hari | Gunakan proyek uji terpisah |
| T-04 | P1 | Tombol "Unduh cadangan" (JSON gabungan struktur, alur, riwayat) | 0,5 hari | Cadangan lengkap, bukan hanya CSV |
| T-05 | P2 | Peran pengguna: admin, editor, pembaca (tabel `pengguna_peran`) | 3 hari | Ubah kebijakan RLS |
| T-06 | P2 | Alur status perubahan (draf, diajukan, disetujui, terbit) | 4 hari | Gunakan kolom status pada tabel versi |
| T-07 | P2 | Tabel `versi` (snapshot per SK, nomor dan tanggal SK) | 3 hari | Termasuk tampilan perbandingan dua versi |
| T-08 | P2 | Periode jabatan pada pejabat dan pengingat jabatan berakhir | 2 hari | Dari kolom tambahan di teks atau tabel terpisah |
| T-09 | P2 | Concurrency: kolom `diubah` sebagai syarat tulis (compare-and-set) | 1 hari | Untuk multi-editor |
| T-10 | P2 | Navigasi keyboard pada simpul bagan (panah, Enter) | 2 hari | Aksesibilitas |
| T-11 | P2 | Uji pointer pada layar sentuh dan Safari iOS | 1 hari | Pengujian manual |
| T-12 | P3 | Kolom formasi dan jumlah pegawai per satuan | 4 hari | Basis untuk ABK |
| T-13 | P3 | Impor data pegawai dari berkas ekspor sumber resmi, dengan validasi | 5 hari | Format perlu disepakati |
| T-14 | P3 | Dashboard rasio formasi dan kebutuhan | 4 hari | Setelah T-12 |
| T-15 | P3 | Pemetaan kode satuan ke kode unit organisasi kepegawaian | 2 hari | Bergantung pada aturan kode instansi |

## 14. Modul kapasitas (v3)

### 14.1. Model data
Tabel `kapasitas` berisi satu baris (`id = 1`) dengan kolom `isi` berjenis jsonb: `{ rows: [...] }`. Setiap baris: `gedung`, `kode`, `nama`, `kodeInst`, `kelas`, `tt`, `berlaku` (YYYY-MM-DD), `sk`.

Alasan satu baris JSON, bukan tabel per ruangan: volume datanya kecil (ratusan baris), penulisan dilakukan oleh satu admin, dan pola ini sama dengan `struktur`. Jika volume tumbuh atau banyak pengguna menulis bersamaan, pindahkan ke tabel baris per ruangan dengan kunci `(kode, berlaku)`.

### 14.2. Aturan periode berlaku
Untuk tanggal `T`, setiap ruangan diambil baris dengan `berlaku <= T` yang terbaru. Baris dengan `berlaku > T` diabaikan. Ruangan dengan `tt = 0` tetap dihitung sebagai ruangan, tetapi tidak menambah total.

### 14.3. Validasi impor
- Galat (menolak impor): TT bukan bilangan bulat, tanggal bukan YYYY-MM-DD, kode ruangan kosong, kode instalasi kosong, pasangan kode dan tanggal berlaku ganda.
- Peringatan (tetap diimpor): kode instalasi tidak ada di daftar organisasi.

### 14.4. Pencocokan dengan SK
`cekTotal(total, expected)` mengembalikan selisih dan status. Angka SK diisi di antarmuka, default 851, dan tidak disimpan di basis data. Keputusan ini disengaja: angka SK adalah masukan verifikasi, bukan data tetap.

### 14.5. Batas yang disengaja
Perhitungan BOR dan ABK tidak dilakukan di aplikasi. Aplikasi menyediakan data induk dan ekspor CSV. Rumus BOR dan standar kebutuhan tenaga dihitung di luar aplikasi.

### 14.6. Pengujian
- Unit: 10 uji di `tests/test.js` bagian [8] untuk parsing, validasi, periode berlaku, total, dan CSV.
- Antarmuka: 7 uji di `tests/ui-test.js` bagian [D] untuk impor, pencocokan SK, impor ditolak, tanggal, ekspor, dan penyimpanan cloud.

## 15. Cadangan dan pemulihan (v3.1)

Format berkas cadangan: `{ aplikasi, versi, dibuat, struktur: {teks}, alur: {kunci: {n, e}}, kapasitas: {rows}, riwayat: [...] }`.

`validasiCadangan` memeriksa: nama aplikasi, tipe setiap bagian, pola kunci diagram (`[A-Za-z0-9._-]{1,64}`), bahwa setiap baris kapasitas punya kode, TT bilangan bulat tidak negatif, dan tanggal YYYY-MM-DD. Batas: 2 MB untuk teks daftar, 50.000 baris kapasitas.

Pemulihan menulis ke semua tabel dan mencatat satu entri riwayat. Riwayat lama tidak dikembalikan. Cadangan sebelum pemulihan disimpan di `localStorage` sebagai `pra_pulih`.
