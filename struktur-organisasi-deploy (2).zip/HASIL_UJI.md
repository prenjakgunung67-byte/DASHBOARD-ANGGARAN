# Hasil Uji (v3.1.1)

Dibuat pada 19 November 2026. Paket dijalankan ulang dari hasil unzip, dengan npm install dari nol.

```
npm install && npm test
```

## 1. Uji unit (tests/test.js)
```

[1] Penguraian daftar
  OK   satu akar, struktur default terurai
  OK   banyak akar memakai akar virtual "Organisasi"
  OK   pejabat diambil dari kolom setelah "|"
  OK   kode {KODE} diambil dan tidak ikut ke nama
  OK   kelompok (# ...) tidak dianggap satuan
  OK   nomor baris disimpan untuk fitur "Lihat di daftar"
  OK   teks kosong menghasilkan akar virtual tanpa anak

[2] Kompatibilitas dengan v1
  OK   hash id v1 sama dengan hid() v2 untuk semua satuan default
  OK   jumlah satuan default sama dengan v1
  OK   diagram v1 (kunci hash) tetap terbaca sebagai kunci lama
  OK   setelah diberi kode, kunci baru dipakai, tetapi diagram lama tetap dibaca

[3] Analisis struktur
  OK   deteksi nama ganda sebagai galat
  OK   deteksi kode ganda sebagai galat
  OK   rentang kendali lebar diberi peringatan
  OK   pejabat kosong terdeteksi
  OK   satuan tanpa diagram dihitung
  OK   rata-rata dan maksimum rentang kendali benar
  OK   jumlah tingkat dan per-tingkat benar
  OK   kelompok tidak menambah tingkat organisasi (hanya kolom tampilan)
  OK   CSV mencantumkan tingkat organisasi tanpa terpengaruh kelompok
  OK   kelompok tidak menambah jumlah satuan

[4] Impor spreadsheet
  OK   impor dengan header dan kelompok
  OK   impor dengan pemisah titik koma (format Excel Indonesia)
  OK   impor kosong menghasilkan teks kosong
  OK   hasil impor memuat semua satuan dan induknya benar
  OK   lingkaran induk ditolak dengan pesan yang menyebut nama satuan

[5] Ekspor CSV
  OK   CSV memakai BOM, pemisah ";" dan tanda kutip ganda
  OK   CSV mencantumkan tingkat dan bawahan langsung

[6] Keamanan isi
  OK   nama dengan karakter HTML tidak mengubah struktur pohon

[7] Pohon dan pencarian jalur
  OK   findByPath menemukan satuan lewat jalurnya

[8] Kapasitas tempat tidur (v3)
  OK   impor dengan judul kolom menghasilkan baris tanpa galat
  OK   TT bukan bilangan dan tanggal salah menjadi galat dan menolak impor
  OK   kode ruangan dan tanggal berlaku yang sama dua kali menjadi galat
  OK   kode instalasi yang tidak ada di organisasi menjadi peringatan, bukan galat
  OK   tanggal berlaku: versi terbaru yang sudah berlaku dipakai, versi masa depan diabaikan
  OK   ruangan ditutup (TT 0) tetap dihitung sebagai ruangan, tidak menambah TT
  OK   rincian per instalasi diurutkan dari TT terbanyak dan jumlahnya benar
  OK   cekTotal menandai selisih terhadap angka SK
  OK   CSV ruangan memakai BOM dan pemisah titik koma
  OK   ringkasan CSV berisi baris TOTAL

[9] Cadangan (v3.1)
  OK   cadangan yang dibuat lalu divalidasi lolos
  OK   validasi menolak aplikasi lain, alur rusak, TT negatif, dan tanggal salah

Hasil: 42 lulus, 0 gagal
```

## 2. Uji antarmuka (tests/ui-test.js)
```

[A] Mode demo (tanpa Supabase)
  OK   halaman langsung terbuka tanpa login dan menampilkan status demo
  OK   bagan default tergambar: 60 satuan + 13 kelompok = 73 simpul
  OK   statistik di bilah atas sesuai analisis
  OK   klik satuan menampilkan rincian dan pejabat
  OK   ketik di daftar langsung memperbarui bagan
  OK   pencarian menurunkan opasitas satuan yang tidak cocok
  OK   tab Analisis menampilkan 6 kartu dan temuan
  OK   unduh CSV menghasilkan berkas bernama struktur-organisasi.csv
  OK   ekspor SVG berjalan dan memakai nama berkas yang benar
  OK   impor spreadsheet mengganti daftar (dengan konfirmasi) dan memberi tahu jumlahnya
  OK   impor yang kosong ditolak dengan peringatan, daftar tidak berubah
  OK   impor lingkaran induk menampilkan galat, daftar tidak berubah
  OK   "Tampilkan di daftar" menyorot baris satuan pada daftar
  OK   "Buka diagram alur" berpindah ke tab Alur dan memilih satuan itu
  OK   tombol Ciutkan menyembunyikan anak satuan; Buka semua mengembalikannya
  OK   klik temuan di tab Analisis membuka satuan di daftar
  OK   kotak alur bisa ditambah dengan tombol Proses dan mencatat jumlah kotak

[B] Alur kerja dan migrasi data v1
  OK   daftar draf v1 (org2) terbaca otomatis
  OK   diagram v1 tetap terbaca pada satuan yang sama (kunci lama)
  OK   menambah kode {KODE} tidak menghilangkan diagram lama
  OK   tab Alur: tambah kotak Proses lalu tersimpan ke penyimpanan lokal
  OK   tombol "Isi dengan contoh" memuat contoh 6 kotak dan 6 garis

[C] Mode cloud (Supabase tiruan)
  OK   masuk menampilkan aplikasi; password salah menampilkan pesan
  OK   masuk dengan benar memuat daftar dan menulis data awal ke cloud + riwayat
  OK   setiap perubahan daftar tercatat di riwayat (tidak diringkas)
  OK   riwayat tampil di tab Analisis
  OK   diagram tersimpan di cloud dimuat ulang lewat kunci kode
  OK   tombol Keluar terlihat di mode cloud

[D] Kapasitas tempat tidur (v3)
  OK   impor data kapasitas menampilkan total dan status sesuai SK (851)
  OK   kode instalasi yang belum ada di daftar tampil sebagai peringatan, impor tetap berhasil
  OK   angka SK diubah menjadi 850 memunculkan selisih dan status belum sesuai
  OK   impor dengan TT tidak valid ditolak dan data sebelumnya tetap
  OK   tanggal sebelum berlaku menghasilkan total nol
  OK   unduh ruangan dan ringkasan CSV berjalan
  OK   mode cloud: data kapasitas disimpan ke tabel kapasitas dan tercatat di riwayat

[E] Cadangan, pemulihan, dan pembatalan (v3.1)
  OK   unduh cadangan menghasilkan berkas JSON dengan nama bertanggal
  OK   cadangan yang valid bisa dipulihkan setelah data diubah
  OK   berkas yang bukan JSON ditolak dan data tidak berubah
  OK   cadangan dari aplikasi lain atau struktur rusak ditolak
  OK   pembatalan impor kapasitas mengembalikan total sebelumnya dan bisa dibalik lagi
  OK   tidak ada galat JavaScript di dalam halaman selama uji

Hasil UI: 41 lulus, 0 gagal
```

## 3. Pemeriksaan tambahan

| Pemeriksaan | Alat | Hasil |
|---|---|---|
| CSP aktif di Chromium: skrip inline yang disuntikkan diblokir dan tercatat | Playwright | Lolos (diblokir, tercatat) |
| CSP tidak memicu pelanggaran pada alur normal (tab, bagan, rincian) | Playwright | 0 pelanggaran, 0 galat |
| Sintaks SQL schema.sql, migrasi/002, migrasi/003 | pglast | Lolos |
| Sintaks core.js, app.js, config.js | node --check | Lolos |
| Data 2.000 ruangan, 3 periode | node | 23 ms; total cocok dengan perhitungan manual |

## 4. Yang belum diuji

- **Uji RLS dengan akun non-admin di Supabase sungguhan.** Lakukan dengan TESTING_RLS.md sebelum data nyata dimasukkan.
- Proyek Supabase sungguhan secara umum (Auth, kuota).
- Data SK yang sebenarnya; pengujian memakai data contoh.
- Perangkat sentuh, Safari, Firefox, dan pembaca layar.

## 5. Temuan selama pengembangan v3.1 yang sudah diperbaiki

| Temuan | Perbaikan |
|---|---|
| Impor kapasitas tidak bisa dibatalkan | Tombol pembatalan dengan tukar dua arah (uji: pembatalan dan pembalikan) |
| Cadangan belum ada; pemulihan belum ada | Cadangan JSON dan pemulihan dengan validasi (uji: berkas rusak, aplikasi lain, pulihkan cadangan valid) |
